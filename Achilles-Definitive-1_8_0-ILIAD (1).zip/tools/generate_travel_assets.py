#!/usr/bin/env python3
"""
Assets y datos del Mapa de Achilles y el Ojo de Achilles (1.7.0): texturas de los items, pergamino y marcador
de la pantalla del mapa, modelos, recetas y textos (se fusionan con los lang existentes).

Uso:  python3 tools/generate_travel_assets.py      (solo necesita Pillow)
"""
import json
import math
import os
import random

from PIL import Image, ImageDraw, ImageFont

MOD = "achilles"
HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.normpath(os.path.join(HERE, "..", "src", "main", "resources"))
ASSETS = os.path.join(RES, "assets", MOD)
DATA = os.path.join(RES, "data", MOD)
rng = random.Random(1707)


def wjson(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def save(img, rel):
    path = os.path.join(ASSETS, "textures", rel)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img.save(path)


def ascii_icon(rows, legend):
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    assert len(rows) == 16, len(rows)
    for y, row in enumerate(rows):
        assert len(row) == 16, (y, row, len(row))
        for x, ch in enumerate(row):
            if ch != ".":
                img.putpixel((x, y), legend[ch] + (255,))
    return img


# ============================================================ marcador de estatua (casco de Aquiles)
def make_marker():
    legend = {
        "k": (58, 38, 20), "g": (226, 176, 58), "h": (255, 229, 128), "d": (160, 112, 34),
        "r": (190, 35, 45), "f": (40, 26, 16), "R": (130, 20, 30),
    }
    rows = [
        "......rrrr......",
        ".....rrrrrr.....",
        "....rrRrrrrR....",
        "...kkkkkkkkkk...",
        "..kghhhhhhhggk..",
        ".kghhggggggggdk.",
        ".kgggggggggggdk.",
        ".kggkfffffkggdk.",
        ".kggkfffffkggdk.",
        ".kggkfkkkfkggdk.",
        ".kgdkfffffkdgdk.",
        "..kdkfffffkddk..",
        "...kkdfffdkk....",
        "....kkkkkkk.....",
        "................",
        "................",
    ]
    save(ascii_icon(rows, legend), "gui/statue_marker.png")


# ============================================================ item: mapa de Achilles (pergamino enrollado)
def make_map_item():
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    outline = (92, 60, 30, 255)
    paper = (232, 208, 158, 255)
    paper_d = (206, 176, 120, 255)
    rod = (140, 98, 52, 255)
    gold = (240, 200, 80, 255)
    red = (190, 35, 45, 255)
    ink = (150, 110, 60, 255)
    d.rectangle((3, 2, 12, 13), fill=paper, outline=outline)
    d.rectangle((4, 3, 11, 12), fill=paper)
    for y in range(3, 13):
        img.putpixel((11, y), paper_d)
    d.rectangle((1, 1, 2, 14), fill=rod, outline=outline)
    d.rectangle((13, 1, 14, 14), fill=rod, outline=outline)
    for x, y in ((1, 0), (2, 0), (1, 15), (2, 15), (13, 0), (14, 0), (13, 15), (14, 15)):
        img.putpixel((x, y), gold)
    # camino punteado y X roja
    for x, y in ((4, 10), (5, 9), (6, 10), (7, 9), (8, 8)):
        img.putpixel((x, y), ink)
    for x, y in ((9, 5), (11, 5), (10, 6), (9, 7), (11, 7)):
        img.putpixel((x, y), red)
    # montañitas
    for x, y in ((5, 5), (4, 6), (6, 6)):
        img.putpixel((x, y), ink)
    save(img, "item/achilles_map.png")


# ============================================================ item: ojo de Achilles
def make_eye_item():
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    gold = (226, 176, 58, 255)
    gold_d = (160, 112, 34, 255)
    white = (245, 245, 235, 255)
    cyan = (110, 220, 255, 255)
    cyan_d = (50, 150, 200, 255)
    black = (20, 16, 24, 255)
    cx, cy = 7.5, 7.5
    for x in range(16):
        for y in range(16):
            u = (x - cx) / 7.0
            v = (y - cy) / 4.4
            r = u * u + v * v
            # almendra: dos arcos
            half = 4.6 * math.sin(math.pi * (x - 0.5) / 15.0) if 0.5 <= x <= 15.5 else 0
            inside = abs(y - cy) <= half - 0.4
            edge = abs(abs(y - cy) - half) < 0.9 and half > 0.6
            if edge:
                img.putpixel((x, y), gold if y < cy else gold_d)
            elif inside:
                img.putpixel((x, y), white)
    for x in range(16):
        for y in range(16):
            dist = math.hypot(x - cx, y - cy)
            if img.getpixel((x, y))[3] == 0:
                continue
            if dist <= 3.4:
                img.putpixel((x, y), cyan if dist > 1.6 else black)
                if dist > 2.6:
                    img.putpixel((x, y), cyan_d)
    img.putpixel((6, 6), (255, 255, 255, 255))
    # rayos dorados (símbolo del ojo)
    for x, y in ((7, 0), (8, 0), (3, 1), (12, 1), (7, 14), (8, 14), (3, 13), (12, 13)):
        img.putpixel((x, y), gold)
    save(img, "item/achilles_eye.png")


# ============================================================ pergamino de la pantalla del mapa (384x240)
def smooth_noise(n, amp, wavelength):
    phases = [rng.random() * math.tau for _ in range(3)]
    out = []
    for i in range(n):
        v = sum(math.sin(i / wavelength * (k + 1) * 1.7 + phases[k]) / (k + 1) for k in range(3))
        out.append(v * amp + rng.uniform(-1.2, 1.2))
    return out


def make_parchment():
    W, H = 384, 240
    img = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    left = smooth_noise(H, 2.2, 14)
    right = smooth_noise(H, 2.2, 14)
    top = smooth_noise(W, 2.2, 18)
    bottom = smooth_noise(W, 2.2, 18)
    base = (226, 200, 150)
    for y in range(H):
        for x in range(W):
            l = 6 + left[y]
            r = W - 7 + right[y]
            t = 6 + top[x]
            b = H - 7 + bottom[x]
            if x < l or x > r or y < t or y > b:
                continue
            edge = min(x - l, r - x, y - t, b - y)
            f = 1.0
            if edge < 26:
                f = 0.74 + 0.26 * (edge / 26.0)
            n = rng.uniform(-5, 5)
            col = tuple(max(0, min(255, int(c * f + n))) for c in base)
            if edge < 2.5:
                col = (130, 92, 50)
            img.putpixel((x, y), col + (255,))

    layer = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ld = ImageDraw.Draw(layer)
    # manchas de humedad
    for _ in range(9):
        cx, cy = rng.randint(30, W - 30), rng.randint(30, H - 30)
        rx, ry = rng.randint(14, 38), rng.randint(10, 26)
        ld.ellipse((cx - rx, cy - ry, cx + rx, cy + ry), fill=(150, 105, 55, 20))
    img = Image.alpha_composite(img, layer)

    d = ImageDraw.Draw(img)
    ink = (110, 74, 38, 255)
    ink_l = (178, 144, 96, 255)
    # marco doble
    d.rectangle((15, 15, W - 16, H - 16), outline=ink)
    d.rectangle((18, 18, W - 19, H - 19), outline=ink_l)
    # esquinas ornamentales
    for (x, y, sx, sy) in ((15, 15, 1, 1), (W - 16, 15, -1, 1), (15, H - 16, 1, -1), (W - 16, H - 16, -1, -1)):
        d.polygon([(x, y), (x + 9 * sx, y), (x, y + 9 * sy)], fill=ink)
        d.polygon([(x + 3 * sx, y + 3 * sy), (x + 7 * sx, y + 3 * sy), (x + 3 * sx, y + 7 * sy)], fill=(226, 200, 150, 255))
    # cuadrícula tenue de cartógrafo
    for gx in range(40, W - 24, 32):
        for gy in range(22, H - 22, 4):
            d.point((gx, gy), fill=ink_l)
    for gy in range(38, H - 24, 32):
        for gx in range(22, W - 22, 4):
            d.point((gx, gy), fill=ink_l)
    # montañas y árboles de adorno
    for _ in range(26):
        x, y = rng.randint(30, W - 40), rng.randint(30, H - 36)
        kind = rng.random()
        if kind < 0.5:
            d.line((x - 4, y + 3, x, y - 2), fill=ink_l)
            d.line((x, y - 2, x + 4, y + 3), fill=ink_l)
            d.line((x + 1, y + 1, x + 3, y - 1), fill=ink_l)
        else:
            d.ellipse((x - 2, y - 3, x + 2, y + 1), outline=ink_l)
            d.line((x, y + 1, x, y + 4), fill=ink_l)
    # rosa de los vientos (abajo a la derecha)
    cx, cy = W - 52, H - 52
    d.ellipse((cx - 17, cy - 17, cx + 17, cy + 17), outline=ink)
    d.ellipse((cx - 14, cy - 14, cx + 14, cy + 14), outline=ink_l)
    d.polygon([(cx, cy - 16), (cx + 4, cy), (cx, cy + 16), (cx - 4, cy)], fill=ink)
    d.polygon([(cx - 16, cy), (cx, cy - 4), (cx + 16, cy), (cx, cy + 4)], fill=ink_l)
    d.polygon([(cx, cy - 16), (cx + 4, cy), (cx - 4, cy)], fill=(139, 26, 26, 255))
    try:
        font = ImageFont.load_default()
        d.text((cx - 3, cy - 30), "N", fill=ink, font=font)
    except Exception:
        pass
    save(img, "gui/map_parchment.png")


# ============================================================ modelos y recetas
def models_and_recipes():
    for name in ("achilles_map", "achilles_eye"):
        wjson(os.path.join(ASSETS, "models", "item", name + ".json"),
              {"parent": "minecraft:item/generated", "textures": {"layer0": "%s:item/%s" % (MOD, name)}})

    wjson(os.path.join(DATA, "recipes", "achilles_map.json"), {
        "type": "minecraft:crafting_shapeless",
        "category": "misc",
        "ingredients": [{"item": "minecraft:map"}, {"item": "minecraft:compass"}, {"item": "minecraft:gold_ingot"}],
        "result": {"item": "%s:achilles_map" % MOD},
    })
    wjson(os.path.join(DATA, "recipes", "achilles_eye.json"), {
        "type": "minecraft:crafting_shaped",
        "category": "misc",
        "pattern": ["AGA", "GEG", "AGA"],
        "key": {
            "A": {"item": "minecraft:amethyst_shard"},
            "G": {"item": "minecraft:gold_ingot"},
            "E": {"item": "minecraft:ender_eye"},
        },
        "result": {"item": "%s:achilles_eye" % MOD},
    })


# ============================================================ textos
ES = {
    "item.achilles.achilles_map": "Mapa de Achilles",
    "item.achilles.achilles_eye": "Ojo de Achilles",
    "tooltip.achilles.map": "Clic derecho: abre el mapa y viaja a una estatua desbloqueada.",
    "tooltip.achilles.eye": "Clic derecho: elige una estatua y contempla su zona libremente. Mantén Shift para salir.",
    "tooltip.achilles.statue_owner": "Propietario: %s",
    "tooltip.achilles.statue_levels": "Radio %s · Curación %s · Mini Aquiles %s",
    "message.achilles.too_close": "Hay otra estatua demasiado cerca: sus zonas se tocarían.",
    "message.achilles.radius_capped": "Otra estatua cercana impide que el radio crezca más.",
    "message.achilles.statue_picked": "Has recogido la estatua. Colócala donde quieras.",
    "message.achilles.carry_unlocked": "¡Esta estatua ya tiene nivel 25! Ahora puedes recogerla picándola.",
    "message.achilles.perk_unlocked": "¡Nueva ventaja en la zona de la estatua: %s!",
    "message.achilles.teleported": "Viajas a %s.",
    "message.achilles.teleport_denied": "No tienes permiso para entrar en la zona de esa estatua.",
    "message.achilles.not_holding": "Necesitas tener el Mapa o el Ojo de Achilles en la mano.",
    "message.achilles.statue_missing": "Esa estatua ya no está.",
    "message.achilles.nick_saved": "Apodo guardado.",
    "message.achilles.eye_start": "Contemplas el santuario con el Ojo de Achilles. Mantén Shift para salir.",
    "message.achilles.eye_hint": "Ojo de Achilles · mantén Shift para salir · %s s",
    "message.achilles.eye_end": "El Ojo de Achilles se cierra.",
    "message.achilles.eye_timeout": "El Ojo se cierra: has contemplado demasiado tiempo.",
    "message.achilles.eye_lost": "La estatua ya no está al alcance: el Ojo se cierra.",
    "screen.achilles.map.title": "Mapa de Achilles",
    "screen.achilles.eye.title": "Ojo de Achilles",
    "screen.achilles.map.action_teleport": "Teletransportarse",
    "screen.achilles.map.action_eye": "Mirar con el Ojo",
    "screen.achilles.map.rename": "Apodar",
    "screen.achilles.map.nick_hint": "Apodo de la estatua",
    "screen.achilles.map.statue_of": "Estatua de %s",
    "screen.achilles.map.nobody": "nadie",
    "screen.achilles.map.none": "Aún no has desbloqueado ninguna estatua de Achilles. Encuentra una (o reclama una) y aparecerá aquí.",
    "screen.achilles.map.select_hint": "Elige una estatua del mapa · rueda: zoom · arrastrar: mover",
    "screen.achilles.map.info": "%s · X %s Y %s Z %s %s",
    "screen.achilles.map.locked": "(zona restringida)",
    "screen.achilles.map.owner": "Propietario: %s",
    "screen.achilles.map.coords": "X %s  Y %s  Z %s",
    "screen.achilles.map.radius": "Radio: %s bloques",
    "screen.achilles.map.distance": "A %s bloques de ti",
    "screen.achilles.dim.overworld": "Mundo normal",
    "screen.achilles.dim.the_nether": "Nether",
    "screen.achilles.dim.the_end": "End",
    "screen.achilles.radius_value": "%s bloques",
    "screen.achilles.radius_cap": "(máx. %s)",
    "screen.achilles.total": "Nivel de la estatua: %s",
    "screen.achilles.perks": "Ventajas: %s/%s",
    "screen.achilles.perks_title": "Ventajas por nivel de la estatua",
    "screen.achilles.next_perk": "Siguiente (Nv. %s): %s",
    "screen.achilles.all_perks": "¡Todas las ventajas activas!",
    "screen.achilles.carry_yes": "Puedes recogerla picándola (solo tú)",
    "screen.achilles.carry_no": "Con nivel total %s podrás recogerla picándola",
    "screen.achilles.blessing": "Curación: Nv. 25 = Regeneración · Nv. 75 = Resistencia",
    "perk.achilles.carry": "Puedes recoger la estatua y llevarla donde quieras",
    "perk.achilles.1": "Prisa I",
    "perk.achilles.2": "Velocidad I",
    "perk.achilles.3": "Visión nocturna",
    "perk.achilles.4": "Cultivos y plantas crecen más rápido",
    "perk.achilles.5": "Respiración acuática y salto mejorado",
    "perk.achilles.6": "Las crías crecen más rápido",
    "perk.achilles.7": "Prisa II y Velocidad II",
    "perk.achilles.8": "Suerte II",
    "perk.achilles.9": "Fuerza II",
}

EN = {
    "item.achilles.achilles_map": "Map of Achilles",
    "item.achilles.achilles_eye": "Eye of Achilles",
    "tooltip.achilles.map": "Right click: open the map and travel to an unlocked statue.",
    "tooltip.achilles.eye": "Right click: pick a statue and freely watch its zone. Hold Shift to leave.",
    "tooltip.achilles.statue_owner": "Owner: %s",
    "tooltip.achilles.statue_levels": "Radius %s · Healing %s · Mini Achilles %s",
    "message.achilles.too_close": "Another statue is too close: their zones would touch.",
    "message.achilles.radius_capped": "A nearby statue stops the radius from growing further.",
    "message.achilles.statue_picked": "You picked up the statue. Place it wherever you like.",
    "message.achilles.carry_unlocked": "This statue reached level 25! You can now pick it up by mining it.",
    "message.achilles.perk_unlocked": "New perk in the statue's zone: %s!",
    "message.achilles.teleported": "You travel to %s.",
    "message.achilles.teleport_denied": "You don't have permission to enter that statue's zone.",
    "message.achilles.not_holding": "You need to hold the Map or the Eye of Achilles.",
    "message.achilles.statue_missing": "That statue is gone.",
    "message.achilles.nick_saved": "Nickname saved.",
    "message.achilles.eye_start": "You watch the sanctuary through the Eye of Achilles. Hold Shift to leave.",
    "message.achilles.eye_hint": "Eye of Achilles · hold Shift to leave · %s s",
    "message.achilles.eye_end": "The Eye of Achilles closes.",
    "message.achilles.eye_timeout": "The Eye closes: you watched for too long.",
    "message.achilles.eye_lost": "The statue is out of reach: the Eye closes.",
    "screen.achilles.map.title": "Map of Achilles",
    "screen.achilles.eye.title": "Eye of Achilles",
    "screen.achilles.map.action_teleport": "Teleport",
    "screen.achilles.map.action_eye": "Watch with the Eye",
    "screen.achilles.map.rename": "Nickname",
    "screen.achilles.map.nick_hint": "Statue nickname",
    "screen.achilles.map.statue_of": "%s's statue",
    "screen.achilles.map.nobody": "nobody",
    "screen.achilles.map.none": "You haven't unlocked any Achilles statue yet. Find one (or claim one) and it will show up here.",
    "screen.achilles.map.select_hint": "Pick a statue on the map · wheel: zoom · drag: move",
    "screen.achilles.map.info": "%s · X %s Y %s Z %s %s",
    "screen.achilles.map.locked": "(restricted zone)",
    "screen.achilles.map.owner": "Owner: %s",
    "screen.achilles.map.coords": "X %s  Y %s  Z %s",
    "screen.achilles.map.radius": "Radius: %s blocks",
    "screen.achilles.map.distance": "%s blocks away",
    "screen.achilles.dim.overworld": "Overworld",
    "screen.achilles.dim.the_nether": "Nether",
    "screen.achilles.dim.the_end": "End",
    "screen.achilles.radius_value": "%s blocks",
    "screen.achilles.radius_cap": "(max %s)",
    "screen.achilles.total": "Statue level: %s",
    "screen.achilles.perks": "Perks: %s/%s",
    "screen.achilles.perks_title": "Perks by statue level",
    "screen.achilles.next_perk": "Next (Lv. %s): %s",
    "screen.achilles.all_perks": "All perks active!",
    "screen.achilles.carry_yes": "You can pick it up by mining it (owner only)",
    "screen.achilles.carry_no": "At total level %s you can pick it up by mining it",
    "screen.achilles.blessing": "Healing: Lv. 25 = Regeneration · Lv. 75 = Resistance",
    "perk.achilles.carry": "You can pick up the statue and carry it anywhere",
    "perk.achilles.1": "Haste I",
    "perk.achilles.2": "Speed I",
    "perk.achilles.3": "Night Vision",
    "perk.achilles.4": "Crops and plants grow faster",
    "perk.achilles.5": "Water Breathing and Jump Boost",
    "perk.achilles.6": "Baby animals grow faster",
    "perk.achilles.7": "Haste II and Speed II",
    "perk.achilles.8": "Luck II",
    "perk.achilles.9": "Strength II",
}


def merge_lang():
    for fname, extra in (("es_es.json", ES), ("en_us.json", EN)):
        path = os.path.join(ASSETS, "lang", fname)
        data = {}
        if os.path.exists(path):
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
        data.update(extra)
        wjson(path, data)


if __name__ == "__main__":
    make_marker()
    make_map_item()
    make_eye_item()
    make_parchment()
    models_and_recipes()
    merge_lang()
    print("OK: assets del Mapa y del Ojo de Achilles generados")
