#!/usr/bin/env python3
"""
Assets de la Espada y el Escudo de Achilles, el Bronce de Troya y Héctor (1.8.0): texturas, modelos, recetas y textos.
Uso:  python3 tools/generate_gear_assets.py      (solo necesita Pillow)
"""
import json
import math
import os
import random

from PIL import Image

MOD = "achilles"
HERE = os.path.dirname(os.path.abspath(__file__))
RES = os.path.normpath(os.path.join(HERE, "..", "src", "main", "resources"))
ASSETS = os.path.join(RES, "assets", MOD)
DATA = os.path.join(RES, "data", MOD)
rng = random.Random(1808)


def wjson(path, obj):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def save(img, rel):
    path = os.path.join(ASSETS, "textures", rel)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    img.save(path)


def clamp(v):
    return max(0, min(255, int(v)))


def shade(c, f):
    return (clamp(c[0] * f), clamp(c[1] * f), clamp(c[2] * f))


# ============================================================ items 16x16
def make_sword():
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    edge_d = (150, 100, 30)
    gold = (240, 196, 72)
    gold_l = (255, 236, 150)
    red = (190, 35, 45)
    dark = (58, 38, 20)
    # hoja diagonal (de abajo-izquierda a arriba-derecha)
    for i in range(5, 14):
        x, y = i, 15 - i
        img.putpixel((x, y), gold_l + (255,))
        if x + 1 < 16:
            img.putpixel((x + 1, y), gold + (255,))
        if y + 1 < 16:
            img.putpixel((x, y + 1), gold + (255,))
        if x + 1 < 16 and y + 1 < 16:
            img.putpixel((x + 1, y + 1), edge_d + (255,))
    img.putpixel((14, 1), gold_l + (255,))
    img.putpixel((14, 0), gold_l + (255,))
    img.putpixel((15, 0), gold + (255,))
    # guarda (perpendicular a la hoja)
    for k in range(-3, 4):
        x, y = 5 + k + 1, 10 + k - 1 + 1
        if 0 <= x < 16 and 0 <= y < 16:
            pass
    for (x, y) in ((3, 8), (4, 9), (5, 10), (6, 11), (7, 12), (2, 7)):
        img.putpixel((x, y), (255, 215, 80, 255))
    for (x, y) in ((4, 8), (5, 9), (6, 10), (7, 11), (3, 7)):
        img.putpixel((x, y), (180, 125, 40, 255))
    # empuñadura y pomo
    for (x, y) in ((3, 12), (2, 13)):
        img.putpixel((x, y), (120, 78, 48, 255))
    img.putpixel((4, 11), (120, 78, 48, 255))
    img.putpixel((1, 14), red + (255,))
    img.putpixel((0, 15), dark + (255,))
    img.putpixel((1, 15), dark + (255,))
    img.putpixel((0, 14), dark + (255,))
    save(img, "item/achilles_sword.png")


def make_shield():
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    cx = cy = 7.5
    gold = (255, 215, 80)
    bronze = (196, 142, 60)
    bronze_d = (140, 96, 38)
    red = (190, 35, 45)
    dark = (58, 38, 20)
    for x in range(16):
        for y in range(16):
            d = math.hypot(x - cx, y - cy)
            if d > 7.6:
                continue
            if d > 6.7:
                col = dark
            elif d > 5.4:
                col = gold if (x + y) % 5 else (255, 240, 160)
            elif d > 4.2:
                col = bronze_d
            elif d > 2.0:
                col = shade(bronze, 1.1 - (y - cy) * 0.03)
            elif d > 1.0:
                col = red
            else:
                col = (255, 236, 150)
            img.putpixel((x, y), col + (255,))
    # rayos del escudo (el cosmos de Aquiles)
    for (x, y) in ((7, 3), (8, 3), (7, 12), (8, 12), (3, 7), (3, 8), (12, 7), (12, 8)):
        img.putpixel((x, y), gold + (255,))
    save(img, "item/achilles_shield.png")


def make_bronze():
    img = Image.new("RGBA", (16, 16), (0, 0, 0, 0))
    dark = (58, 38, 20)
    for y in range(5, 12):
        off = (y - 5) // 2
        for x in range(2 + off, 12 + off):
            top = y == 5 or x == 2 + off
            col = (230, 175, 80) if top else (190, 135, 55)
            if y >= 10:
                col = (140, 96, 38)
            img.putpixel((x, y), col + (255,))
    for y in range(4, 13):
        off = max(0, (y - 5) // 2)
        for x in (1 + off, 12 + off):
            if 0 <= x < 16 and 5 <= y <= 11:
                img.putpixel((x, y), dark + (255,))
    for x in range(2, 15):
        img.putpixel((min(15, x), 4), dark + (255,)) if 4 < 5 and 3 <= x <= 12 else None
        img.putpixel((min(15, x), 12), dark + (255,)) if 4 <= x <= 14 else None
    for (x, y) in ((4, 6), (5, 6), (6, 6)):
        img.putpixel((x, y), (255, 236, 150, 255))
    save(img, "item/trojan_bronze.png")


# ============================================================ piel de Héctor (64x64)
SKIN = (232, 190, 150)
BEARD = (92, 62, 40)
BLUE = (34, 58, 120)
BLUE_D = (24, 40, 88)
BRONZE = (190, 140, 62)
GOLD = (240, 196, 72)
RED = (190, 35, 45)
LEATHER = (110, 72, 44)
DARK = (40, 30, 30)

LIGHT = {"top": 1.05, "bottom": 0.78, "right": 0.92, "left": 0.92, "front": 1.0, "back": 0.88}


def faces(u, v, w, h, d):
    return {"top": (u + d, v, w, d), "bottom": (u + d + w, v, w, d),
            "right": (u, v + d, d, h), "front": (u + d, v + d, w, h),
            "left": (u + d + w, v + d, d, h), "back": (u + 2 * d + w, v + d, w, h)}


def paint(img, box, base, only=None, noise=3):
    for name, (x0, y0, rw, rh) in faces(*box).items():
        if only and name not in only:
            continue
        for y in range(rh):
            for x in range(rw):
                n = rng.randint(-noise, noise)
                c = shade(base, LIGHT[name])
                img.putpixel((x0 + x, y0 + y), (clamp(c[0] + n), clamp(c[1] + n), clamp(c[2] + n), 255))


def band(img, box, face_names, row0, row1, base, noise=3):
    """Pinta filas row0..row1 (incluidas) de las caras laterales de una caja."""
    for name in face_names:
        x0, y0, rw, rh = faces(*box)[name]
        for y in range(row0, min(row1, rh - 1) + 1):
            for x in range(rw):
                n = rng.randint(-noise, noise)
                c = shade(base, LIGHT[name])
                img.putpixel((x0 + x, y0 + y), (clamp(c[0] + n), clamp(c[1] + n), clamp(c[2] + n), 255))


SIDES = ("right", "front", "left", "back")


def make_hector():
    img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    # cabeza (0,0,8,8,8)
    head = (0, 0, 8, 8, 8)
    paint(img, head, SKIN)
    fx, fy, _, _ = faces(*head)["front"]
    band(img, head, ("front",), 6, 7, BEARD)           # barba
    band(img, head, ("right", "left", "back"), 0, 2, BEARD)
    for ex in (1, 5):                                  # ojos
        img.putpixel((fx + ex, fy + 4), (255, 255, 255, 255))
        img.putpixel((fx + ex + 1, fy + 4), DARK + (255,))
    for ex in (1, 2, 5, 6):                            # cejas
        img.putpixel((fx + ex, fy + 3), BEARD + (255,))
    # casco (capa exterior de la cabeza, 32,0)
    helm = (32, 0, 8, 8, 8)
    paint(img, helm, BRONZE, only=("top",))
    band(img, helm, SIDES, 0, 3, BRONZE)
    band(img, helm, ("right", "left"), 4, 7, BRONZE)   # carrilleras
    hfx, hfy, _, _ = faces(*helm)["front"]
    for yy in range(4, 7):                             # protector de nariz
        for xx in (3, 4):
            img.putpixel((hfx + xx, hfy + yy), shade(BRONZE, 1.1) + (255,))
    for xx in range(8):                                # ribete dorado
        img.putpixel((hfx + xx, hfy + 3), GOLD + (255,))
    tx, ty, tw, th = faces(*helm)["top"]               # cresta roja sobre el casco
    for yy in range(th):
        for xx in (3, 4):
            img.putpixel((tx + xx, ty + yy), RED + (255,))
    for name in ("front", "back"):
        x0, y0, rw, rh = faces(*helm)[name]
        for xx in (3, 4):
            for yy in range(0, 2):
                img.putpixel((x0 + xx, y0 + yy), RED + (255,))
    # cuerpo (16,16,8,12,4): túnica azul, coraza de bronce
    body = (16, 16, 8, 12, 4)
    paint(img, body, BLUE)
    band(img, body, ("front", "back"), 0, 7, BRONZE)
    bx, by, bw, bh = faces(*body)["front"]
    for yy in range(0, 8):
        img.putpixel((bx + 3, by + yy), shade(BRONZE, 1.15) + (255,))
        img.putpixel((bx + 4, by + yy), shade(BRONZE, 0.9) + (255,))
    for xx in range(bw):
        img.putpixel((bx + xx, by + 7), GOLD + (255,))
    band(img, body, SIDES, 8, 8, LEATHER)              # cinturón
    for xx in (3, 4):
        img.putpixel((bx + xx, by + 8), GOLD + (255,))
    band(img, body, SIDES, 9, 11, BLUE_D)               # falda
    # brazos: derecho (40,16) e izquierdo (32,48)
    for box in ((40, 16, 4, 12, 4), (32, 48, 4, 12, 4)):
        paint(img, box, SKIN)
        band(img, box, SIDES, 0, 2, GOLD)               # hombrera
        band(img, box, SIDES, 3, 5, BLUE)               # manga
        band(img, box, SIDES, 9, 11, BRONZE)            # brazalete
    # piernas: derecha (0,16) e izquierda (16,48)
    for box in ((0, 16, 4, 12, 4), (16, 48, 4, 12, 4)):
        paint(img, box, SKIN)
        band(img, box, SIDES, 0, 2, BLUE_D)
        band(img, box, SIDES, 5, 10, BRONZE)            # grebas
        band(img, box, SIDES, 11, 11, LEATHER)          # sandalias
    save(img, "entity/hector.png")


# ============================================================ modelos y recetas
def models_and_recipes():
    for name, parent in (("achilles_sword", "minecraft:item/handheld"), ("achilles_shield", "minecraft:item/generated"),
                         ("trojan_bronze", "minecraft:item/generated")):
        wjson(os.path.join(ASSETS, "models", "item", name + ".json"),
              {"parent": parent, "textures": {"layer0": "%s:item/%s" % (MOD, name)}})

    wjson(os.path.join(DATA, "recipes", "achilles_sword.json"), {
        "type": "minecraft:crafting_shaped", "category": "equipment",
        "pattern": [" B ", "BNB", " R "],
        "key": {"B": {"item": "%s:trojan_bronze" % MOD}, "N": {"item": "minecraft:netherite_ingot"},
                "R": {"item": "minecraft:blaze_rod"}},
        "result": {"item": "%s:achilles_sword" % MOD},
    })
    wjson(os.path.join(DATA, "recipes", "achilles_shield.json"), {
        "type": "minecraft:crafting_shaped", "category": "equipment",
        "pattern": ["BNB", "BBB", " B "],
        "key": {"B": {"item": "%s:trojan_bronze" % MOD}, "N": {"item": "minecraft:netherite_ingot"}},
        "result": {"item": "%s:achilles_shield" % MOD},
    })


ES = {
    "item.achilles.achilles_sword": "Espada de Achilles",
    "item.achilles.achilles_shield": "Escudo de Achilles",
    "item.achilles.trojan_bronze": "Bronce de Troya",
    "item.achilles.hector_spawn_egg": "Huevo generador de Héctor",
    "entity.achilles.hector": "Héctor, príncipe de Troya",
    "tooltip.achilles.sword.1": "Irrompible · 14 de daño · cada golpe ignora armadura, ralentiza y te cura",
    "tooltip.achilles.sword.2": "Clic derecho: Embestida (cargas atravesando enemigos)",
    "tooltip.achilles.sword.3": "Agachado + clic derecho: Ira de Aquiles (60 s de espera)",
    "tooltip.achilles.shield.1": "Irrompible · sostenerlo da resistencia al fuego y al daño",
    "tooltip.achilles.shield.2": "Al bloquear: devuelve el doble del daño, empuja y te cura",
    "tooltip.achilles.shield.3": "Refleja proyectiles · onda de choque al bloquear (cada 8 s)",
    "message.achilles.wrath": "¡La ira de Aquiles te consume!",
    "message.achilles.hector_cry": "Héctor lanza su grito de guerra: te sientes débil.",
}
EN = {
    "item.achilles.achilles_sword": "Sword of Achilles",
    "item.achilles.achilles_shield": "Shield of Achilles",
    "item.achilles.trojan_bronze": "Trojan Bronze",
    "item.achilles.hector_spawn_egg": "Hector Spawn Egg",
    "entity.achilles.hector": "Hector, Prince of Troy",
    "tooltip.achilles.sword.1": "Unbreakable · 14 damage · every hit ignores armor, slows and heals you",
    "tooltip.achilles.sword.2": "Right click: Charge (dash through enemies)",
    "tooltip.achilles.sword.3": "Sneak + right click: Wrath of Achilles (60 s cooldown)",
    "tooltip.achilles.shield.1": "Unbreakable · holding it grants fire and damage resistance",
    "tooltip.achilles.shield.2": "On block: returns double the damage, knocks back and heals you",
    "tooltip.achilles.shield.3": "Reflects projectiles · shockwave on block (every 8 s)",
    "message.achilles.wrath": "The wrath of Achilles consumes you!",
    "message.achilles.hector_cry": "Hector lets out a war cry: you feel weak.",
}


def merge_lang():
    for fname, extra in (("es_es.json", ES), ("en_us.json", EN)):
        path = os.path.join(ASSETS, "lang", fname)
        data = {}
        if os.path.exists(path):
            with open(path, encoding="utf-8") as f:
                data = json.load(f)
        data.update(extra)
        wjson(path, data)


if __name__ == "__main__":
    make_sword()
    make_shield()
    make_bronze()
    make_hector()
    models_and_recipes()
    merge_lang()
    print("OK: assets de la espada, el escudo, el bronce y Héctor generados")
