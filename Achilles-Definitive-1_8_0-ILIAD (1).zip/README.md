# 🗿 Achilles — mod para Minecraft Forge 1.20.1

Estatuas de un antiguo guerrero (Aquiles) repartidas por el mundo, con una **zona sagrada** a su alrededor,
y un **mini Aquiles** adorable y torpe que intenta ser el héroe de la leyenda.

## Las estatuas

- **Aparecen solas** en el Overworld: una por región de 24×24 chunks, siempre en la zona central de la región.
  Así dos estatuas quedan separadas **más de ~225 bloques**, y como el radio máximo es 108, **las zonas no chocan**.
  Además, el radio de una estatua nunca puede crecer hasta tocar la zona de otra (la pantalla muestra el máximo posible). Cada estatua se genera sobre una plataforma de ladrillos con pilares rotos y 1-2 mini Aquiles de guardia.
- **Indestructibles**: ni jugadores (ni en creativo), ni explosiones, ni Wither/Dragón, ni pistones.
- **Zona de inmunidad** (radio base 8 bloques):
  - Los mobs hostiles no pueden aparecer dentro, son empujados fuera al acercarse y los que se cuelan se desvanecen. Los jefes solo son repelidos.
  - Los jugadores dentro no reciben daño (salvo vacío y `/kill`) y recuperan vida cada segundo.
- **Propiedad**: el primer jugador que interactúa (clic derecho) con una estatua sin dueño la reclama.
  Mientras no tiene dueño, protege y cura a todo el mundo. Cuando tiene dueño, **solo entran él y los jugadores a los que dé permiso**;
  el resto es expulsado del área. Los administradores en creativo (permiso 2) pueden entrar.
- **Mejoras** (clic derecho como propietario → pantalla): cada punto se invierte en **Radio** o en **Curación**, hasta nivel 100 en cada una, por estatua.
  Los puntos son del jugador y se reparten entre todas sus estatuas.

| | Nivel 0 | Nivel 100 |
|---|---|---|
| Radio | 8 bloques | 108 bloques (+1 por nivel) |
| Curación | 0,5 vida/s | 10,5 vida/s (+0,1 por nivel) |

Extras de curación: nivel 25+ da Regeneración, nivel 50+ limpia efectos negativos, nivel 75+ da Resistencia y nivel 100 también sacia el hambre. Las explosiones tampoco destruyen bloques dentro de una zona protegida.
Los números están en `data/StatueStats.java`.

En la pantalla de la estatua también se dan o quitan permisos escribiendo el nombre de un jugador (hasta 20).

## Novedades 1.8.0 — Ilíada

- **Héctor, príncipe de Troya** (el enemigo mortal de Aquiles): jefe raro y hostil con barra de jefe (160 de vida, armadura, casi no retrocede).
  Aparece muy de vez en cuando en llanuras, sabana, desierto, mesa, prados y bosques (huevo generador en la pestaña creativa).
  Odia a Aquiles: ataca a los mini Aquiles y golpea con rencor extra a quien lleve la Espada o el Escudo de Achilles. Con menos de la mitad de vida se enfurece
  y su grito de guerra debilita a los jugadores cercanos. Las estatuas lo repelen (no lo eliminan) como a cualquier jefe.
  Suelta **Bronce de Troya** (4-6, más con Looting).
- **Espada de Achilles**: irrompible, 14 de daño. Cada golpe ignora la armadura (daño mágico extra), ralentiza y te cura.
  Clic derecho = **Embestida** (9 bloques atravesando enemigos, 5 s de espera). Agachado + clic derecho = **Ira de Aquiles** (10 s de Fuerza III, Velocidad II, Resistencia II, Absorción y fuego; 60 s de espera).
- **Escudo de Achilles (la Égida)**: irrompible. Sostenerlo da resistencia al fuego y al daño y +60 % de resistencia al empuje. Al bloquear devuelve el **doble del daño** y empuja al atacante,
  te cura, **refleja proyectiles** y cada 8 s lanza una **onda de choque** (8 de daño y empuje en 6 bloques).
- Recetas: **Espada** `_B_ / BNB / _R_` y **Escudo** `BNB / BBB / _B_`, con B = Bronce de Troya, N = lingote de netherita, R = vara de blaze.

## Novedades 1.7.0 — Odisea

- **Radio**: cada punto de radio suma **1 bloque** (nivel 100 = 108 bloques).
- **Nivel de la estatua** = radio + curación + mini Aquiles (máx. 300).
- **Recoger la estatua**: con nivel total **25+**, su propietario puede picarla (~2,5 s). Va a su inventario con propietario, niveles y permisos, y se coloca donde quiera
  (no se puede colocar si su zona tocaría la de otra estatua). Los guardianes del sitio viejo se despiden y aparecen nuevos en el nuevo.
- **Ventajas en la zona** según el nivel total: 25 Prisa I · 50 Velocidad I · 75 Visión nocturna · 100 cultivos crecen más rápido · 125 Respiración acuática y salto mejorado ·
  150 crías crecen más rápido · 200 Prisa II y Velocidad II · 250 Suerte II · 300 Fuerza II. Se ven al pasar el ratón por el nivel en la pantalla de la estatua.
- **Mapa de Achilles** (shapeless: mapa + brújula + lingote de oro): pergamino medieval con un icono por estatua desbloqueada (encontrada o tuya), con su nombre.
  Rueda = zoom, arrastrar = mover. Eliges una estatua, le pones **apodo** (solo lo ves tú) y te **teletransportas** junto a ella (espera de 5 s; solo a zonas donde tengas permiso).
- **Ojo de Achilles** (amatista/oro/ojo de Ender, ver receta abajo): abre el mismo mapa, y al elegir una estatua pasas a **modo espectador** dentro de su zona (no puedes salir de ella).
  **Mantén Shift 1,5 s** para volver (o a los 5 min). Tu posición y modo de juego originales se guardan, incluso si te desconectas.
- Las estatuas de mundos anteriores aparecen en el mapa tras volver a pasar cerca de ellas una vez (el servidor las indexa al cargarlas).

Recetas: **Mapa** = 1 mapa vacío + 1 brújula + 1 lingote de oro (sin forma). **Ojo** = `A G A / G E G / A G A` con A = fragmento de amatista, G = lingote de oro, E = ojo de Ender.
Números en `data/StatueStats.java` (`CARRY_LEVEL`, `PERK_LEVELS`).

## Puntos por encontrar estatuas (1.6.0)

Cada jugador gana **5 puntos** la primera vez que *encuentra* una estatua (acercándose a menos de 24 bloques o al radio de su zona, lo que sea mayor, o tocándola). Cada estatua da puntos una sola vez por jugador. Los puntos se gastan en las estatuas que posees.

## Mini Aquiles mejorable (1.6.0)

En la pantalla de la estatua hay una tercera mejora: **Mini Aquiles** (nivel 0-100). Cada nivel da +0,5 de vida y +0,1 de daño a los guardianes de esa estatua (nivel 100: 62 de vida y 11 de daño, sumado a los bonos de la curación). Se aplica al instante a los guardianes que ya existen.

## Santuario total (1.6.0)

- **Mobs del jugador protegidos**: mascotas (lobos, gatos, loros...), caballos domados, golems de hierro construidos por jugadores y mini Aquiles no reciben ningún daño dentro de la zona (salvo vacío y `/kill`), y se curan. Quien los ataque recibe el daño reflejado.
- **Lo de dentro no se puede romper**: sin permiso nadie puede picar, colocar, usar bloques ni interactuar con entidades de la zona; los mobs hostiles no destruyen ni mueven bloques (enderman, zombis con puertas, wither, dragón, creepers...); las explosiones no rompen bloques ni dañan nada de dentro; ningún pistón de fuera puede empujar, tirar ni destruir bloques de la zona; el fuego que aparezca se apaga al instante; no se pisotean los cultivos; y los objetos tirados dentro no se queman ni explotan.
- Los propietarios y jugadores con permiso sí pueden construir y picar dentro de su zona con normalidad.
- Límites: el agua y la lava que fluyan desde fuera no se detienen.

## Escudo reflectante (1.5.0)

- **Proyectiles**: flechas, tridentes, bolas de fuego, calaveras del Wither, pociones, perlas de Ender, bolas de nieve, etc. que vayan a **entrar** en la zona rebotan en su superficie y salen disparados **de vuelta hacia quien los lanzó** (o espejados si no se sabe quién fue). Los proyectiles de jugadores con permiso atraviesan la zona con normalidad, y los cohetes de fuegos artificiales se ignoran.
- **Daño**: todo daño dirigido a algo protegido (jugadores con permiso, mini Aquiles, animales, aldeanos...) se cancela y se **devuelve al atacante** (hasta 40 de daño por golpe). Los jugadores con permiso pueden dañar a los seres no hostiles de dentro; entre ellos no hay reflejo.
- Con la estatua sin dueño todo el mundo cuenta como "con permiso", así que solo se reflejan los ataques de mobs.

## La guardia de Aquiles

La progresión de una estatua también afecta a sus guardianes:
- Una estatua mantiene al menos **1 mini Aquiles** cerca.
- Radio nivel 25/50/75 desbloquea progresivamente hasta **4 guardianes**.
- Curación nivel 25/50/75 mejora su resistencia y daño en tres escalones.
- Los guardianes recuerdan su puesto, vuelven después del combate y no se alejan indefinidamente.
- Si la estatua está cargada, el sistema revisa periódicamente que su guardia siga presente.

## El mini Aquiles

Guerrero diminuto con casco de cresta roja, peto de bronce, grebas, escudo, espadita y capa.
Practica con la espada, **se tropieza y se queda tumbado**, y se cree el héroe: ataca monstruos (menos creepers)… aunque pega con cosquillas.
Sonidos propios (¡piii!, ¡eek!, tropiezo, clang de juguete…) sintetizados en `tools/generate_assets.py`.
Aparece en llanuras, bosques, sabana y prados, y cerca de las estatuas. Los guardianes de una estatua son persistentes y están ligados a su puesto. Huevo generador en la pestaña creativa.

## Zona visible

La zona de protección se muestra automáticamente durante unos segundos a intervalos regulares. No registra ninguna tecla nueva, para evitar conflictos con otros mods.

## Compilar

Requisitos: **JDK 17**, y para generar assets **Python 3 + Pillow + numpy + ffmpeg** (los assets ya vienen generados en el repo;
solo se vuelven a generar si borras `src/main/resources/assets`).

1. Copia `gradlew`, `gradlew.bat` y `gradle/wrapper/gradle-wrapper.jar` del
   [MDK oficial de Forge 1.20.1](https://files.minecraftforge.net/net/minecraftforge/forge/index_1.20.1.html), o usa
   el workflow de GitHub Actions incluido (`.github/workflows/build.yml`), que compila el jar sin wrapper.
2. `./gradlew build` → jar en `build/libs/`. Para probar: `./gradlew runClient`.

## Administradores

La Estatua de Aquiles está en la pestaña creativa para colocarla a mano (2 de alto, mira hacia ti al colocarla).

## Licencia

MIT.
