package com.achilles.gear;

import com.achilles.entity.AchillesEntity;
import com.achilles.registry.ModItems;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.phys.Vec3;

/** Habilidades del Escudo de Achilles (la Égida) y utilidades para detectar el equipo de Achilles. */
public final class AchillesGear {
    private static final String NEXT_WAVE = "AchillesAegisNext";
    private static final int WAVE_COOLDOWN = 160;

    private AchillesGear() {
    }

    public static boolean holdsShield(LivingEntity entity) {
        return entity.getMainHandItem().is(ModItems.SHIELD.get()) || entity.getOffhandItem().is(ModItems.SHIELD.get());
    }

    public static boolean holdsAny(LivingEntity entity) {
        return holdsShield(entity) || entity.getMainHandItem().is(ModItems.SWORD.get())
                || entity.getOffhandItem().is(ModItems.SWORD.get());
    }

    public static boolean isBlockingWithShield(Player player) {
        return player.isBlocking() && player.getUseItem().is(ModItems.SHIELD.get());
    }

    /** Pasiva: mientras lo sostienes, resistencia al fuego y al daño. */
    public static void tick(ServerPlayer player) {
        if (player.tickCount % 20 == 0 && holdsShield(player)) {
            player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 60, 0, true, false, true));
            player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 60, 0, true, false, true));
        }
    }

    /** Un golpe fue bloqueado con la Égida: devuelve el doble del daño, empuja, cura y (cada 8 s) lanza una onda de choque. */
    public static void onAegisBlock(Player player, DamageSource source, float blocked) {
        Entity attacker = source.getEntity();
        if (attacker instanceof LivingEntity target && target != player && target.isAlive()) {
            target.hurt(player.damageSources().thorns(player), Mth.clamp(blocked * 2.0F, 6.0F, 60.0F));
            target.knockback(1.6D, player.getX() - target.getX(), player.getZ() - target.getZ());
        }
        player.heal(2.0F);

        long now = player.level().getGameTime();
        CompoundTag data = player.getPersistentData();
        if (now >= data.getLong(NEXT_WAVE)) {
            data.putLong(NEXT_WAVE, now + WAVE_COOLDOWN);
            shockwave(player);
        }
    }

    private static void shockwave(Player player) {
        for (LivingEntity e : player.level().getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(6.0D),
                e -> e != player && e.isAlive() && !(e instanceof Player) && !(e instanceof AchillesEntity)
                        && !(e instanceof OwnableEntity pet && player.getUUID().equals(pet.getOwnerUUID())))) {
            e.hurt(player.damageSources().playerAttack(player), 8.0F);
            e.knockback(1.8D, player.getX() - e.getX(), player.getZ() - e.getZ());
        }
        if (player.level() instanceof ServerLevel level) {
            level.sendParticles(ParticleTypes.EXPLOSION, player.getX(), player.getY(0.5D), player.getZ(), 3, 1.5D, 0.3D, 1.5D, 0.0D);
            level.sendParticles(ParticleTypes.ENCHANTED_HIT, player.getX(), player.getY(0.8D), player.getZ(), 40, 2.0D, 0.5D, 2.0D, 0.3D);
            level.playSound(null, player.blockPosition(), SoundEvents.ANVIL_LAND, SoundSource.PLAYERS, 1.0F, 0.6F);
        }
    }

    /** Un proyectil que iba a golpear al jugador mientras bloquea con la Égida sale devuelto hacia donde mira. */
    public static boolean reflectProjectile(Player player, Projectile projectile) {
        Vec3 toProjectile = projectile.position().subtract(player.position());
        Vec3 look = player.getLookAngle();
        if (toProjectile.dot(look) <= 0.0D) return false;       // viene por la espalda: no lo detiene
        float speed = (float) Math.max(1.6D, projectile.getDeltaMovement().length());
        projectile.setOwner(player);
        projectile.shoot(look.x, look.y, look.z, speed, 0.0F);
        projectile.hasImpulse = true;
        if (player.level() instanceof ServerLevel level) {
            level.sendParticles(ParticleTypes.ENCHANTED_HIT, projectile.getX(), projectile.getY(), projectile.getZ(), 8, 0.2D, 0.2D, 0.2D, 0.1D);
            level.playSound(null, player.blockPosition(), SoundEvents.SHIELD_BLOCK, SoundSource.PLAYERS, 1.0F, 1.4F);
        }
        return true;
    }
}
