package com.achilles.block;

import com.achilles.data.PointsData;
import com.achilles.data.StatueRegistry;
import com.achilles.data.StatueIndexData;
import com.achilles.data.StatueStats;
import com.achilles.registry.ModItems;
import com.achilles.entity.AchillesEntity;
import com.achilles.registry.ModEntities;
import com.achilles.network.NetworkHandler;
import com.achilles.network.OpenStatuePacket;
import com.achilles.registry.ModBlockEntities;
import com.mojang.authlib.GameProfile;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.CactusBlock;
import net.minecraft.world.level.block.CocoaBlock;
import net.minecraft.world.level.block.CropBlock;
import net.minecraft.world.level.block.NetherWartBlock;
import net.minecraft.world.level.block.SaplingBlock;
import net.minecraft.world.level.block.StemBlock;
import net.minecraft.world.level.block.SugarCaneBlock;
import net.minecraft.world.level.block.SweetBerryBushBlock;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.projectile.AbstractHurtingProjectile;
import net.minecraft.world.entity.projectile.FireworkRocketEntity;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraftforge.fml.util.ObfuscationReflectionHelper;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.effect.MobEffectCategory;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.monster.Enemy;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.common.Tags;
import net.minecraftforge.network.PacketDistributor;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.HashSet;
import java.util.Optional;
import java.util.UUID;

/**
 * Cerebro de la estatua: propietario, niveles, jugadores con permiso, y la zona:
 * repele/elimina mobs hostiles, expulsa a jugadores sin permiso y cura a los que están dentro.
 */
public class StatueBlockEntity extends BlockEntity {
    private UUID owner;
    private String ownerName = "";
    private int radiusLevel;
    private int healLevel;
    private int guardLevel;
    /** Identidad propia de la estatua: se conserva al recogerla y colocarla en otro sitio. */
    private UUID statueId;
    /** Clave antigua (dimensión|posición) de la 1.6.0, para no perder las estatuas ya descubiertas. */
    private String legacyKey = "";
    private boolean indexed;
    private final Map<UUID, String> trusted = new LinkedHashMap<>();
    private int ticks;

    public StatueBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.STATUE.get(), pos, state);
    }

    // ------------------------------------------------------------ ciclo de vida

    @Override
    public void onLoad() {
        super.onLoad();
        if (this.level != null && !this.level.isClientSide) {
            StatueRegistry.add(this);
        }
    }

    @Override
    public void setRemoved() {
        super.setRemoved();
        StatueRegistry.remove(this);
    }

    // ------------------------------------------------------------ datos

    public boolean hasOwner() {
        return owner != null;
    }

    public boolean isOwner(Player player) {
        return owner != null && owner.equals(player.getUUID());
    }

    @Nullable
    public UUID getStatueId() {
        return statueId;
    }

    public int totalLevel() {
        return StatueStats.totalLevel(radiusLevel, healLevel, guardLevel);
    }

    /** Solo el propietario, y solo a partir del nivel total 25, puede recoger la estatua. */
    public boolean canBeCarriedBy(Player player) {
        return isOwner(player) && StatueStats.canCarry(totalLevel());
    }

    private static String dimKey(Level level) {
        return level.dimension().location().toString();
    }

    private void ensureId(ServerLevel serverLevel) {
        boolean changed = false;
        if (statueId == null || StatueRegistry.isIdUsedByOther(statueId, this)) {
            boolean duplicate = statueId != null;
            statueId = UUID.randomUUID();
            if (duplicate) legacyKey = "";
            changed = true;
        }
        if (legacyKey.isEmpty()) {
            legacyKey = dimKey(serverLevel) + "|" + worldPosition.asLong();
            changed = true;
        }
        if (changed) setChanged();
    }

    /** Actualiza el índice global (mapa, ojo, solapamiento de zonas) con el estado actual de la estatua. */
    private void syncIndex(ServerLevel serverLevel) {
        ensureId(serverLevel);
        StatueIndexData.get(serverLevel.getServer()).put(new StatueIndexData.Entry(statueId, dimKey(serverLevel),
                worldPosition.asLong(), owner, ownerName, legacyKey, getRadius(), java.util.Set.copyOf(new HashSet<>(trusted.keySet()))));
        indexed = true;
    }

    /** Envía al cliente lo mínimo (propietario y niveles) para que sepa si puede recoger la estatua. */
    private void syncClient() {
        if (this.level != null && !this.level.isClientSide) {
            this.level.sendBlockUpdated(worldPosition, getBlockState(), getBlockState(), 3);
        }
    }

    private void syncAll(ServerLevel serverLevel) {
        syncIndex(serverLevel);
        syncClient();
    }

    /** Se llama cuando el bloque desaparece de verdad (no al descargar el chunk). */
    public void onDestroyed() {
        if (this.level instanceof ServerLevel serverLevel && statueId != null) {
            StatueIndexData.get(serverLevel.getServer()).remove(statueId);
        }
    }

    public int radiusCap(ServerLevel serverLevel) {
        if (statueId == null) return StatueStats.MAX_LEVEL;
        double limit = StatueIndexData.get(serverLevel.getServer()).maxRadiusFor(statueId, dimKey(serverLevel), worldPosition);
        return StatueStats.radiusLevelForLimit(limit);
    }

    /** La estatua como objeto, con propietario, niveles, permisos e identidad dentro (BlockEntityTag). */
    public ItemStack createItem() {
        ItemStack stack = new ItemStack(ModItems.STATUE.get());
        CompoundTag tag = this.saveWithoutMetadata();
        BlockItem.setBlockEntityData(stack, ModBlockEntities.STATUE.get(), tag);
        return stack;
    }

    /** El propietario (nivel total 25+) recoge la estatua: va a su inventario y los guardianes se despiden. */
    public void pickUp(ServerPlayer player) {
        if (!(this.level instanceof ServerLevel serverLevel)) return;
        ensureId(serverLevel);
        ItemStack stack = createItem();
        if (!player.getInventory().add(stack)) {
            player.drop(stack, false);
        }
        for (AchillesEntity guard : serverLevel.getEntitiesOfClass(AchillesEntity.class,
                new AABB(worldPosition).inflate(48.0D), g -> worldPosition.equals(g.getGuardPost()))) {
            serverLevel.sendParticles(ParticleTypes.POOF, guard.getX(), guard.getY(0.5D), guard.getZ(), 8, 0.2D, 0.2D, 0.2D, 0.02D);
            guard.discard();
        }
        serverLevel.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, worldPosition.getX() + 0.5D, worldPosition.getY() + 1.2D,
                worldPosition.getZ() + 0.5D, 30, 0.5D, 0.8D, 0.5D, 0.2D);
        serverLevel.playSound(null, worldPosition, SoundEvents.AMETHYST_BLOCK_RESONATE, SoundSource.BLOCKS, 1.0F, 0.8F);
        player.displayClientMessage(Component.translatable("message.achilles.statue_picked"), true);
        onDestroyed();
    }

    public double getRadius() {
        return StatueStats.radius(radiusLevel);
    }

    private Vec3 center() {
        return Vec3.atCenterOf(this.worldPosition).add(0.0D, 0.5D, 0.0D);
    }

    /** ¿Este jugador (por UUID) tiene permiso en la zona? Sirve para sus mascotas aunque estén solas. */
    public boolean isAllowed(UUID id) {
        return owner == null || owner.equals(id) || trusted.containsKey(id);
    }

    public boolean contains(Vec3 pos) {
        double r = getRadius();
        return center().distanceToSqr(pos) <= r * r;
    }

    /** Sin propietario: todos. Con propietario: él, los de la lista y administradores en creativo. */
    public boolean isAllowed(Player player) {
        if (owner == null) return true;
        if (owner.equals(player.getUUID()) || trusted.containsKey(player.getUUID())) return true;
        return player.isCreative() && player.hasPermissions(2);
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        if (owner != null) tag.putUUID("Owner", owner);
        tag.putString("OwnerName", ownerName);
        tag.putInt("RadiusLevel", radiusLevel);
        tag.putInt("HealLevel", healLevel);
        tag.putInt("GuardLevel", guardLevel);
        if (statueId != null) tag.putUUID("StatueId", statueId);
        tag.putString("LegacyKey", legacyKey);
        ListTag list = new ListTag();
        for (Map.Entry<UUID, String> e : trusted.entrySet()) {
            CompoundTag entry = new CompoundTag();
            entry.putUUID("Id", e.getKey());
            entry.putString("Name", e.getValue());
            list.add(entry);
        }
        tag.put("Trusted", list);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        owner = tag.hasUUID("Owner") ? tag.getUUID("Owner") : null;
        ownerName = tag.getString("OwnerName");
        radiusLevel = Mth.clamp(tag.getInt("RadiusLevel"), 0, StatueStats.MAX_LEVEL);
        healLevel = Mth.clamp(tag.getInt("HealLevel"), 0, StatueStats.MAX_LEVEL);
        guardLevel = Mth.clamp(tag.getInt("GuardLevel"), 0, StatueStats.MAX_LEVEL);
        statueId = tag.hasUUID("StatueId") ? tag.getUUID("StatueId") : null;
        legacyKey = tag.getString("LegacyKey");
        trusted.clear();
        ListTag list = tag.getList("Trusted", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag entry = list.getCompound(i);
            trusted.put(entry.getUUID("Id"), entry.getString("Name"));
        }
    }

    // ------------------------------------------------------------ sincronización con el cliente

    @Override
    public CompoundTag getUpdateTag() {
        CompoundTag tag = new CompoundTag();
        if (owner != null) tag.putUUID("Owner", owner);
        tag.putString("OwnerName", ownerName);
        tag.putInt("RadiusLevel", radiusLevel);
        tag.putInt("HealLevel", healLevel);
        tag.putInt("GuardLevel", guardLevel);
        return tag;
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    // ------------------------------------------------------------ interacción

    public void interact(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        if (owner == null) {
            owner = player.getUUID();
            ownerName = player.getGameProfile().getName();
            discover(player);
            setChanged();
            syncAll(level);
            level.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, worldPosition.getX() + 0.5D, worldPosition.getY() + 1.5D,
                    worldPosition.getZ() + 0.5D, 40, 0.6D, 1.0D, 0.6D, 0.3D);
            level.playSound(null, worldPosition, SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundSource.BLOCKS, 1.0F, 1.0F);
            player.displayClientMessage(Component.translatable("message.achilles.claimed"), false);
            sendOpen(player);
        } else if (isOwner(player)) {
            sendOpen(player);
        } else if (trusted.containsKey(player.getUUID())) {
            player.displayClientMessage(Component.translatable("message.achilles.trusted", ownerName), true);
        } else {
            player.displayClientMessage(Component.translatable("message.achilles.owned_by", ownerName), true);
        }
    }

    public void sendOpen(ServerPlayer player) {
        if (owner == null) return;
        int points = PointsData.get(player.server).available(owner);
        int cap = Math.max(radiusLevel, radiusCap(player.serverLevel()));
        NetworkHandler.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player),
                new OpenStatuePacket(worldPosition, ownerName, radiusLevel, healLevel, guardLevel, cap, points,
                        new ArrayList<>(trusted.values())));
    }

    /** type 0 = radio, 1 = curación, 2 = mini Aquiles (vida y daño de los guardianes). */
    public void upgrade(ServerPlayer player, int type, int amount) {
        if (!isOwner(player)) return;
        ServerLevel serverLevel = player.serverLevel();
        PointsData data = PointsData.get(player.server);
        int current = type == 0 ? radiusLevel : type == 1 ? healLevel : guardLevel;
        int max = StatueStats.MAX_LEVEL;
        if (type == 0) {
            // el radio no puede crecer hasta tocar la zona de otra estatua
            int cap = radiusCap(serverLevel);
            if (cap < max) max = Math.max(cap, current);
            if (current >= max && current < StatueStats.MAX_LEVEL) {
                player.displayClientMessage(Component.translatable("message.achilles.radius_capped"), true);
            }
        }
        int spend = Math.min(Math.min(amount, max - current), data.available(owner));
        if (spend <= 0) return;
        int totalBefore = totalLevel();
        data.spend(owner, spend);
        if (type == 0) radiusLevel += spend;
        else if (type == 1) healLevel += spend;
        else guardLevel += spend;
        setChanged();
        syncAll(serverLevel);
        if (type == 2) {
            maintainGuardians(serverLevel);   // aplica ya la mejora a los guardianes existentes
        }
        serverLevel.playSound(null, worldPosition, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.BLOCKS, 1.0F, 1.2F);

        int totalAfter = totalLevel();
        if (!StatueStats.canCarry(totalBefore) && StatueStats.canCarry(totalAfter)) {
            player.displayClientMessage(Component.translatable("message.achilles.carry_unlocked"), false);
        }
        int perksBefore = StatueStats.perksUnlocked(totalBefore);
        int perksAfter = StatueStats.perksUnlocked(totalAfter);
        if (perksAfter > perksBefore) {
            player.displayClientMessage(Component.translatable("message.achilles.perk_unlocked",
                    Component.translatable("perk.achilles." + perksAfter)), false);
        }
    }

    public void setTrusted(ServerPlayer player, String name, boolean add) {
        if (!isOwner(player)) return;
        if (add) {
            if (trusted.size() >= 20) return;
            Optional<GameProfile> profile = lookup(player.server, name);
            if (profile.isEmpty()) {
                player.displayClientMessage(Component.translatable("message.achilles.player_not_found", name), true);
                return;
            }
            if (!profile.get().getId().equals(owner)) {
                trusted.put(profile.get().getId(), profile.get().getName());
            }
        } else {
            trusted.entrySet().removeIf(e -> e.getValue().equalsIgnoreCase(name));
        }
        setChanged();
        if (this.level instanceof ServerLevel serverLevel) syncIndex(serverLevel);
    }

    private static Optional<GameProfile> lookup(MinecraftServer server, String name) {
        ServerPlayer online = server.getPlayerList().getPlayerByName(name);
        if (online != null) return Optional.of(online.getGameProfile());
        return server.getProfileCache() == null ? Optional.empty() : server.getProfileCache().get(name);
    }

    // ------------------------------------------------------------ la zona

    public static void serverTick(Level level, BlockPos pos, BlockState state, StatueBlockEntity statue) {
        if (!(level instanceof ServerLevel serverLevel)) return;
        statue.ticks++;
        if (!statue.indexed) statue.syncAll(serverLevel);
        else if (statue.ticks % 1200 == 0) statue.syncIndex(serverLevel);
        if (statue.ticks % 20 == 0) statue.discoverNearby(serverLevel);
        if (statue.ticks % 40 == 0 && statue.totalLevel() >= 100) statue.growPlants(serverLevel);
        if (statue.ticks % 100 == 0 && statue.totalLevel() >= 150) statue.growBabies(serverLevel);
        statue.reflectProjectiles(serverLevel);
        if (statue.ticks % 4 == 0) statue.guard(serverLevel);
        if (statue.ticks % 20 == 0) statue.healPlayers(serverLevel);
        if (statue.ticks % 100 == 0) statue.maintainGuardians(serverLevel);
        if (statue.ticks % 40 == 0) {
            serverLevel.sendParticles(ParticleTypes.END_ROD, pos.getX() + 0.5D, pos.getY() + 2.2D, pos.getZ() + 0.5D,
                    2, 0.3D, 0.2D, 0.3D, 0.01D);
        }
    }

    /** Mantiene una guardia pequeña y persistente. Las mejoras de radio desbloquean más guardianes
     * y las mejoras de curación aumentan su resistencia/daño. */
    private void maintainGuardians(ServerLevel level) {
        int desired = Math.min(4, 1 + radiusLevel / 25);
        int tier = Math.min(3, healLevel / 25);
        AABB area = new AABB(worldPosition).inflate(14.0D);
        int current = level.getEntitiesOfClass(AchillesEntity.class, area, guard ->
                worldPosition.equals(guard.getGuardPost())).size();

        // También actualiza la fuerza de los guardianes existentes cuando sube Curación.
        for (AchillesEntity guard : level.getEntitiesOfClass(AchillesEntity.class, area, g ->
                worldPosition.equals(g.getGuardPost()))) {
            guard.setGuardStats(tier, guardLevel);
        }
        if (current >= desired) {
            return;
        }

        for (int i = current; i < desired; i++) {
            int x = worldPosition.getX() + level.random.nextInt(9) - 4;
            int z = worldPosition.getZ() + level.random.nextInt(9) - 4;
            int y = level.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            if (y <= level.getMinBuildHeight() || y > level.getMaxBuildHeight() - 2) continue;
            if (!level.getBlockState(new BlockPos(x, y - 1, z)).isSolid()) continue;

            AchillesEntity guard = ModEntities.ACHILLES.get().create(level);
            if (guard == null) continue;
            guard.moveTo(x + 0.5D, y, z + 0.5D, level.random.nextFloat() * 360.0F, 0.0F);
            guard.finalizeSpawn(level, level.getCurrentDifficultyAt(worldPosition), MobSpawnType.STRUCTURE, null, null);
            guard.setGuardPost(worldPosition);
            guard.setGuardStats(tier, guardLevel);
            guard.setPersistenceRequired();
            level.addFreshEntity(guard);
        }

        if (desired > 1) {
            level.sendParticles(ParticleTypes.ENCHANT, worldPosition.getX() + 0.5D, worldPosition.getY() + 2.0D,
                    worldPosition.getZ() + 0.5D, 8, 0.7D, 0.6D, 0.7D, 0.05D);
        }
    }

    // ------------------------------------------------------------ descubrimiento

    private static final double DISCOVER_RANGE = 24.0D;
    private static final String SAFE_ITEM_TAG = "achilles_safe_item";

    /** Quien se acerca a una estatua por primera vez la "encuentra" y gana puntos. */
    private void discoverNearby(ServerLevel level) {
        double range = Math.max(getRadius(), DISCOVER_RANGE);
        Vec3 c = center();
        for (ServerPlayer player : level.getEntitiesOfClass(ServerPlayer.class, new AABB(c, c).inflate(range))) {
            if (player.isSpectator() || c.distanceToSqr(player.position()) > range * range) continue;
            discover(player);
        }
    }

    /** Da los puntos de descubrimiento si este jugador no había encontrado antes esta estatua. */
    public boolean discover(ServerPlayer player) {
        ServerLevel level = player.serverLevel();
        ensureId(level);
        if (!PointsData.get(level.getServer()).discover(player.getUUID(), statueId.toString(), legacyKey, StatueStats.DISCOVERY_POINTS)) {
            return false;
        }
        level.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, player.getX(), player.getY(1.0D), player.getZ(),
                25, 0.5D, 0.8D, 0.5D, 0.2D);
        level.playSound(null, player.blockPosition(), SoundEvents.UI_TOAST_CHALLENGE_COMPLETE, SoundSource.PLAYERS, 1.0F, 1.0F);
        player.displayClientMessage(Component.translatable("message.achilles.discovered", StatueStats.DISCOVERY_POINTS), false);
        return true;
    }

    // ------------------------------------------------------------ escudo reflectante

    /** ¿Debe este proyectil atravesar la zona sin ser reflejado? (los disparados por jugadores con permiso) */
    private boolean passesThrough(Projectile projectile) {
        Entity owner = projectile.getOwner();
        return owner instanceof Player player && isAllowed(player);
    }

    /**
     * Cada tick: todo proyectil que fuese a cruzar la superficie de la zona hacia dentro rebota
     * y sale disparado de vuelta hacia quien lo lanzó (o espejado si no se sabe quién fue).
     */
    private void reflectProjectiles(ServerLevel level) {
        double r = getRadius();
        Vec3 c = center();
        AABB box = new AABB(c, c).inflate(r + 12.0D);
        for (Projectile projectile : level.getEntitiesOfClass(Projectile.class, box)) {
            if (projectile.isRemoved() || projectile instanceof FireworkRocketEntity) continue;
            Vec3 vel = projectile.getDeltaMovement();
            double speedSqr = vel.lengthSqr();
            if (speedSqr < 1.0E-4D) continue;                       // clavado o parado
            Vec3 rel = projectile.position().subtract(c);
            double cc = rel.lengthSqr() - r * r;
            if (cc < 0.0D) continue;                                // ya está dentro: no es una entrada
            double b = 2.0D * rel.dot(vel);
            double disc = b * b - 4.0D * speedSqr * cc;
            if (disc <= 0.0D) continue;                             // no toca la esfera
            double t = (-b - Math.sqrt(disc)) / (2.0D * speedSqr);
            if (t < 0.0D || t > 1.0D) continue;                     // no la cruza en este tick
            if (passesThrough(projectile)) continue;
            reflect(level, projectile, c, vel, t);
        }
    }

    private void reflect(ServerLevel level, Projectile projectile, Vec3 c, Vec3 vel, double t) {
        Vec3 entry = projectile.position().add(vel.scale(t));
        Vec3 normal = entry.subtract(c);
        normal = normal.lengthSqr() < 1.0E-6D ? new Vec3(0.0D, 1.0D, 0.0D) : normal.normalize();
        Vec3 outside = entry.add(normal.scale(0.4D));
        double speed = Math.max(vel.length(), 0.6D);

        Vec3 newDir;
        Entity owner = projectile.getOwner();
        if (owner != null && owner.isAlive() && owner.level() == level) {
            Vec3 toOwner = owner.getEyePosition().subtract(outside);
            newDir = toOwner.lengthSqr() > 1.0E-4D ? toOwner.normalize() : normal;
        } else {
            // espejo sobre la superficie de la zona: v' = v - 2 (v·n) n
            Vec3 mirrored = vel.subtract(normal.scale(2.0D * vel.dot(normal)));
            newDir = mirrored.lengthSqr() > 1.0E-6D ? mirrored.normalize() : normal;
        }
        Vec3 newVel = newDir.scale(speed);

        projectile.setPos(outside.x, outside.y, outside.z);
        projectile.setDeltaMovement(newVel);
        projectile.setYRot((float) (Mth.atan2(newVel.x, newVel.z) * (180.0D / Math.PI)));
        projectile.setXRot((float) (Mth.atan2(newVel.y, newVel.horizontalDistance()) * (180.0D / Math.PI)));
        projectile.yRotO = projectile.getYRot();
        projectile.xRotO = projectile.getXRot();
        projectile.hasImpulse = true;
        projectile.hurtMarked = true;

        // Bolas de fuego y calaveras aceleran por su cuenta: se les da la nueva dirección también.
        if (projectile instanceof AbstractHurtingProjectile) {
            try {
                double px = (Double) ObfuscationReflectionHelper.getPrivateValue(AbstractHurtingProjectile.class, (AbstractHurtingProjectile) projectile, "xPower");
                double py = (Double) ObfuscationReflectionHelper.getPrivateValue(AbstractHurtingProjectile.class, (AbstractHurtingProjectile) projectile, "yPower");
                double pz = (Double) ObfuscationReflectionHelper.getPrivateValue(AbstractHurtingProjectile.class, (AbstractHurtingProjectile) projectile, "zPower");
                double mag = Math.sqrt(px * px + py * py + pz * pz);
                if (mag > 0.0D) {
                    ObfuscationReflectionHelper.setPrivateValue(AbstractHurtingProjectile.class, (AbstractHurtingProjectile) projectile, newDir.x * mag, "xPower");
                    ObfuscationReflectionHelper.setPrivateValue(AbstractHurtingProjectile.class, (AbstractHurtingProjectile) projectile, newDir.y * mag, "yPower");
                    ObfuscationReflectionHelper.setPrivateValue(AbstractHurtingProjectile.class, (AbstractHurtingProjectile) projectile, newDir.z * mag, "zPower");
                }
            } catch (RuntimeException ignored) {
                // si el campo no se pudo leer, el proyectil igualmente sale rebotado con su nueva velocidad
            }
        }

        level.sendParticles(ParticleTypes.ENCHANTED_HIT, outside.x, outside.y, outside.z, 12, 0.25D, 0.25D, 0.25D, 0.1D);
        level.sendParticles(ParticleTypes.END_ROD, outside.x, outside.y, outside.z, 4, 0.1D, 0.1D, 0.1D, 0.05D);
        level.playSound(null, outside.x, outside.y, outside.z, SoundEvents.SHIELD_BLOCK, SoundSource.BLOCKS, 1.0F, 1.2F);
    }

    private void guard(ServerLevel level) {
        double r = getRadius();
        Vec3 c = center();
        AABB box = new AABB(c, c).inflate(r + 6.0D);

        for (Mob mob : level.getEntitiesOfClass(Mob.class, box, m -> m instanceof Enemy)) {
            LivingEntity target = mob.getTarget();
            if (target != null && c.distanceToSqr(target.position()) < r * r) {
                mob.setTarget(null);
            }
            double d = Math.sqrt(mob.distanceToSqr(c));
            if (d >= r) continue;

            boolean boss = mob.getType().is(Tags.EntityTypes.BOSSES);
            if (!boss && !mob.hasCustomName() && d < r - 3.0D) {
                level.sendParticles(ParticleTypes.POOF, mob.getX(), mob.getY(0.5D), mob.getZ(), 8, 0.2D, 0.2D, 0.2D, 0.02D);
                mob.discard();
                continue;
            }
            Vec3 away = new Vec3(mob.getX() - c.x, 0.0D, mob.getZ() - c.z);
            if (away.lengthSqr() < 1.0E-4D) away = new Vec3(1.0D, 0.0D, 0.0D);
            away = away.normalize();
            mob.setDeltaMovement(away.x * 0.8D, 0.35D, away.z * 0.8D);
            mob.hurtMarked = true;
            mob.getNavigation().stop();
        }

        for (ServerPlayer player : level.getEntitiesOfClass(ServerPlayer.class, box)) {
            if (!player.isSpectator() && c.distanceToSqr(player.position()) < r * r && !isAllowed(player)) {
                eject(level, player, c, r);
            }
        }

        // Los objetos tirados dentro de la zona no pueden quemarse, explotar ni caer en lava.
        for (ItemEntity item : level.getEntitiesOfClass(ItemEntity.class, box)) {
            boolean inside = c.distanceToSqr(item.position()) <= r * r;
            if (inside && !item.isInvulnerable()) {
                item.setInvulnerable(true);
                item.addTag(SAFE_ITEM_TAG);
            } else if (!inside && item.getTags().contains(SAFE_ITEM_TAG)) {
                item.setInvulnerable(false);
                item.removeTag(SAFE_ITEM_TAG);
            }
        }
    }

    private void eject(ServerLevel level, ServerPlayer player, Vec3 c, double r) {
        Vec3 dir = new Vec3(player.getX() - c.x, 0.0D, player.getZ() - c.z);
        if (dir.lengthSqr() < 1.0E-4D) dir = new Vec3(1.0D, 0.0D, 0.0D);
        dir = dir.normalize();
        double tx = c.x + dir.x * (r + 2.0D);
        double tz = c.z + dir.z * (r + 2.0D);
        int ty = level.getHeight(Heightmap.Types.MOTION_BLOCKING, Mth.floor(tx), Mth.floor(tz));
        player.connection.teleport(tx, ty, tz, player.getYRot(), player.getXRot());
        player.displayClientMessage(Component.translatable("message.achilles.restricted", ownerName), true);
    }

    private void healPlayers(ServerLevel level) {
        double r = getRadius();
        Vec3 c = center();
        float amount = StatueStats.healPerSecond(healLevel);

        // Las mascotas de los jugadores con permiso también se curan dentro de la zona.
        for (TamableAnimal pet : level.getEntitiesOfClass(TamableAnimal.class, new AABB(c, c).inflate(r))) {
            if (pet.getOwnerUUID() != null && isAllowed(pet.getOwnerUUID())
                    && c.distanceToSqr(pet.position()) <= r * r && pet.getHealth() < pet.getMaxHealth()) {
                pet.heal(amount);
            }
        }
        for (ServerPlayer player : level.getEntitiesOfClass(ServerPlayer.class, new AABB(c, c).inflate(r))) {
            if (player.isSpectator() || c.distanceToSqr(player.position()) > r * r || !isAllowed(player)) continue;

            if (player.getHealth() < player.getMaxHealth()) {
                player.heal(amount);
                level.sendParticles(ParticleTypes.HEART, player.getX(), player.getY(1.0D), player.getZ(), 1, 0.3D, 0.3D, 0.3D, 0.0D);
            }
            applyPerks(player);
            // Bendición de Aquiles: las mejoras altas convierten la zona en un santuario real.
            // Se refrescan cada segundo para no crear una cola enorme de efectos.
            if (healLevel >= 25) {
                player.addEffect(new MobEffectInstance(net.minecraft.world.effect.MobEffects.REGENERATION, 30, 0, true, false, true));
            }
            if (healLevel >= 75) {
                player.addEffect(new MobEffectInstance(net.minecraft.world.effect.MobEffects.DAMAGE_RESISTANCE, 30, 0, true, false, true));
            }

            // Mejoras de curación altas: limpia efectos negativos (50+) y sacia el hambre (100)
            if (healLevel >= 50 && ticks % 100 == 0) {
                List<net.minecraft.world.effect.MobEffect> harmful = new ArrayList<>();
                for (MobEffectInstance effect : player.getActiveEffects()) {
                    if (effect.getEffect().getCategory() == MobEffectCategory.HARMFUL) harmful.add(effect.getEffect());
                }
                harmful.forEach(player::removeEffect);
            }
            if (healLevel >= StatueStats.MAX_LEVEL && player.getFoodData().needsFood()) {
                player.getFoodData().eat(1, 0.5F);
            }
        }
    }

    // ------------------------------------------------------------ ventajas por nivel total

    private void perk(ServerPlayer player, net.minecraft.world.effect.MobEffect effect, int amplifier, int duration) {
        player.addEffect(new MobEffectInstance(effect, duration, amplifier, true, false, true));
    }

    /** Ventajas dentro de la zona según el nivel total (radio + curación + mini Aquiles). Ver StatueStats.PERK_LEVELS. */
    private void applyPerks(ServerPlayer player) {
        int total = totalLevel();
        int tier2 = total >= 200 ? 1 : 0;
        if (total >= 25) perk(player, MobEffects.DIG_SPEED, tier2, 60);
        if (total >= 50) perk(player, MobEffects.MOVEMENT_SPEED, tier2, 60);
        if (total >= 75) perk(player, MobEffects.NIGHT_VISION, 0, 260);
        if (total >= 125) {
            perk(player, MobEffects.WATER_BREATHING, 0, 60);
            perk(player, MobEffects.JUMP, 0, 60);
        }
        if (total >= 250) perk(player, MobEffects.LUCK, 1, 60);
        if (total >= 300) perk(player, MobEffects.DAMAGE_BOOST, 1, 60);
    }

    /** Nivel total 100+: los cultivos y plantas de la zona crecen más rápido (ticks aleatorios extra). */
    private void growPlants(ServerLevel serverLevel) {
        double r = getRadius();
        Vec3 c = center();
        int attempts = 16 + Math.min(16, totalLevel() / 20);
        for (int i = 0; i < attempts; i++) {
            double angle = serverLevel.random.nextDouble() * Math.PI * 2.0D;
            double dist = Math.sqrt(serverLevel.random.nextDouble()) * r;
            int x = Mth.floor(c.x + Math.cos(angle) * dist);
            int z = Mth.floor(c.z + Math.sin(angle) * dist);
            if (!serverLevel.hasChunkAt(new BlockPos(x, worldPosition.getY(), z))) continue;
            int y = (i % 2 == 0)
                    ? serverLevel.getHeight(Heightmap.Types.WORLD_SURFACE, x, z)
                    : worldPosition.getY() + serverLevel.random.nextInt(13) - 4;
            BlockPos pos = new BlockPos(x, y, z);
            if (!contains(Vec3.atCenterOf(pos))) continue;
            tryGrow(serverLevel, pos);
            tryGrow(serverLevel, pos.below());
        }
    }

    private void tryGrow(ServerLevel serverLevel, BlockPos pos) {
        BlockState state = serverLevel.getBlockState(pos);
        Block block = state.getBlock();
        if (block instanceof CropBlock || block instanceof StemBlock || block instanceof SaplingBlock
                || block instanceof NetherWartBlock || block instanceof SweetBerryBushBlock
                || block instanceof CocoaBlock || block instanceof SugarCaneBlock || block instanceof CactusBlock) {
            state.randomTick(serverLevel, pos, serverLevel.random);
        }
    }

    /** Nivel total 150+: las crías de la zona crecen más rápido. */
    private void growBabies(ServerLevel serverLevel) {
        double r = getRadius();
        Vec3 c = center();
        for (AgeableMob mob : serverLevel.getEntitiesOfClass(AgeableMob.class, new AABB(c, c).inflate(r),
                m -> m.getAge() < 0 && contains(m.position()))) {
            mob.ageUp(200);
        }
    }
}
