package com.achilles.client;

import com.achilles.data.StatueStats;
import com.achilles.network.NetworkHandler;
import com.achilles.network.OpenStatuePacket;
import com.achilles.network.TrustPacket;
import com.achilles.network.UpgradePacket;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Pantalla del propietario: gastar puntos (radio, curación, mini Aquiles), ver las ventajas y dar permisos. */
public class StatueScreen extends Screen {
    private BlockPos pos;
    private String ownerName;
    private int radiusLevel;
    private int healLevel;
    private int guardLevel;
    private int radiusCap;
    private int points;
    private List<String> trusted;
    private EditBox nameBox;

    public StatueScreen(OpenStatuePacket data) {
        super(Component.translatable("screen.achilles.title"));
        apply(data);
    }

    public BlockPos getPos() {
        return pos;
    }

    public void refresh(OpenStatuePacket data) {
        apply(data);
    }

    private void apply(OpenStatuePacket data) {
        this.pos = data.pos;
        this.ownerName = data.ownerName;
        this.radiusLevel = data.radiusLevel;
        this.healLevel = data.healLevel;
        this.guardLevel = data.guardLevel;
        this.radiusCap = data.radiusCap;
        this.points = data.points;
        this.trusted = data.trusted;
    }

    private int top() {
        return Math.max(2, (this.height - 230) / 2);
    }

    private int total() {
        return StatueStats.totalLevel(radiusLevel, healLevel, guardLevel);
    }

    @Override
    protected void init() {
        int cx = this.width / 2;
        int top = top();

        addRenderableWidget(Button.builder(Component.translatable("screen.achilles.plus1"),
                b -> upgrade(0, 1)).bounds(cx - 155, top + 62, 72, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.achilles.plus10"),
                b -> upgrade(0, 10)).bounds(cx - 79, top + 62, 72, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.achilles.plus1"),
                b -> upgrade(1, 1)).bounds(cx + 7, top + 62, 72, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.achilles.plus10"),
                b -> upgrade(1, 10)).bounds(cx + 83, top + 62, 72, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("screen.achilles.plus1"),
                b -> upgrade(2, 1)).bounds(cx - 155, top + 112, 72, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.achilles.plus10"),
                b -> upgrade(2, 10)).bounds(cx - 79, top + 112, 72, 20).build());

        nameBox = new EditBox(this.font, cx - 130, top + 180, 120, 20, Component.empty());
        nameBox.setMaxLength(16);
        nameBox.setHint(Component.translatable("screen.achilles.player_name"));
        addRenderableWidget(nameBox);

        addRenderableWidget(Button.builder(Component.translatable("screen.achilles.allow"),
                b -> trust(true)).bounds(cx - 2, top + 180, 62, 20).build());
        addRenderableWidget(Button.builder(Component.translatable("screen.achilles.remove"),
                b -> trust(false)).bounds(cx + 64, top + 180, 66, 20).build());

        addRenderableWidget(Button.builder(Component.translatable("gui.done"),
                b -> onClose()).bounds(cx - 50, top + 208, 100, 20).build());
    }

    private void upgrade(int type, int amount) {
        NetworkHandler.CHANNEL.sendToServer(new UpgradePacket(pos, type, amount));
    }

    private void trust(boolean add) {
        String name = nameBox.getValue().trim();
        if (name.isEmpty()) return;
        NetworkHandler.CHANNEL.sendToServer(new TrustPacket(pos, name, add));
        nameBox.setValue("");
    }

    /** Lista completa de ventajas (se enseña al pasar el ratón por el nivel de la estatua). */
    private List<Component> perkTooltip() {
        int total = total();
        List<Component> lines = new ArrayList<>();
        lines.add(Component.translatable("screen.achilles.perks_title").withStyle(ChatFormatting.GOLD));
        boolean carry = StatueStats.canCarry(total);
        lines.add(Component.literal((carry ? "\u2714 " : "\u2718 ") + "Nv. " + StatueStats.CARRY_LEVEL + ": ")
                .append(Component.translatable("perk.achilles.carry"))
                .withStyle(carry ? ChatFormatting.GREEN : ChatFormatting.DARK_GRAY));
        for (int i = 0; i < StatueStats.PERK_LEVELS.length; i++) {
            int level = StatueStats.PERK_LEVELS[i];
            boolean on = total >= level;
            lines.add(Component.literal((on ? "\u2714 " : "\u2718 ") + "Nv. " + level + ": ")
                    .append(Component.translatable("perk.achilles." + (i + 1)))
                    .withStyle(on ? ChatFormatting.GREEN : ChatFormatting.DARK_GRAY));
        }
        return lines;
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics);
        int cx = this.width / 2;
        int top = top();
        int total = total();

        graphics.drawCenteredString(this.font, this.title, cx, top, 0xFFD700);
        graphics.drawCenteredString(this.font, Component.translatable("screen.achilles.owner", ownerName), cx, top + 12, 0xFFFFFF);
        graphics.drawCenteredString(this.font, Component.translatable("screen.achilles.points", points), cx, top + 24, 0x55FF55);

        graphics.drawString(this.font, Component.translatable("screen.achilles.radius", radiusLevel, StatueStats.MAX_LEVEL), cx - 155, top + 40, 0xFFFFFF);
        String radiusText = Component.translatable("screen.achilles.radius_value",
                String.format(Locale.ROOT, "%.0f", StatueStats.radius(radiusLevel))).getString();
        graphics.drawString(this.font, radiusText, cx - 155, top + 50, 0xAAAAAA);
        if (radiusCap < StatueStats.MAX_LEVEL) {
            graphics.drawString(this.font, Component.translatable("screen.achilles.radius_cap", radiusCap),
                    cx - 155 + this.font.width(radiusText) + 6, top + 50, 0xFF5555);
        }
        graphics.drawString(this.font, Component.translatable("screen.achilles.heal", healLevel, StatueStats.MAX_LEVEL), cx + 7, top + 40, 0xFFFFFF);
        graphics.drawString(this.font, Component.translatable("screen.achilles.heal_value",
                String.format(Locale.ROOT, "%.1f", StatueStats.healPerSecond(healLevel))), cx + 7, top + 50, 0xAAAAAA);

        graphics.drawString(this.font, Component.translatable("screen.achilles.guard", guardLevel, StatueStats.MAX_LEVEL), cx - 155, top + 92, 0xFFFFFF);
        graphics.drawString(this.font, Component.translatable("screen.achilles.guard_value",
                String.format(Locale.ROOT, "%.1f", StatueStats.guardHealth(guardLevel)),
                String.format(Locale.ROOT, "%.1f", StatueStats.guardDamage(guardLevel))), cx - 155, top + 102, 0xAAAAAA);

        // nivel total y ventajas (columna derecha)
        int colX = cx + 7;
        graphics.drawString(this.font, Component.translatable("screen.achilles.total", total), colX, top + 92, 0xFFD700);
        graphics.drawString(this.font, Component.translatable("screen.achilles.perks",
                StatueStats.perksUnlocked(total), StatueStats.PERK_LEVELS.length), colX, top + 102, 0x55FFFF);
        int next = StatueStats.nextPerkLevel(total);
        int unlocked = StatueStats.perksUnlocked(total);
        Component nextLine = next < 0
                ? Component.translatable("screen.achilles.all_perks")
                : Component.translatable("screen.achilles.next_perk", next, Component.translatable("perk.achilles." + (unlocked + 1)));
        graphics.drawString(this.font, this.font.plainSubstrByWidth(nextLine.getString(), 150), colX, top + 112, 0xAAAAAA);

        graphics.drawCenteredString(this.font, Component.translatable("screen.achilles.blessing"), cx, top + 138, 0x55FFFF);
        Component carryLine = StatueStats.canCarry(total)
                ? Component.translatable("screen.achilles.carry_yes")
                : Component.translatable("screen.achilles.carry_no", StatueStats.CARRY_LEVEL);
        graphics.drawCenteredString(this.font, carryLine, cx, top + 150, StatueStats.canCarry(total) ? 0x55FF55 : 0xAAAAAA);

        graphics.drawCenteredString(this.font, Component.translatable("screen.achilles.trusted_title"), cx, top + 164, 0xFFD700);
        String list = trusted.isEmpty() ? Component.translatable("screen.achilles.nobody").getString() : String.join(", ", trusted);
        graphics.drawCenteredString(this.font, this.font.plainSubstrByWidth(list, 300), cx, top + 174 - 0, 0xFFFFFF);

        super.render(graphics, mouseX, mouseY, partialTick);

        if (mouseX >= colX && mouseX <= colX + 150 && mouseY >= top + 90 && mouseY <= top + 122) {
            graphics.renderComponentTooltip(this.font, perkTooltip(), mouseX, mouseY);
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
