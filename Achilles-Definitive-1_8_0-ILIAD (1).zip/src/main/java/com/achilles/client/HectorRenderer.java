package com.achilles.client;

import com.achilles.Achilles;
import com.achilles.entity.HectorEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.resources.ResourceLocation;

/** Héctor: un guerrero humanoide, un poco más grande que un jugador. */
public class HectorRenderer extends HumanoidMobRenderer<HectorEntity, HumanoidModel<HectorEntity>> {
    private static final ResourceLocation TEXTURE =
            new ResourceLocation(Achilles.MODID, "textures/entity/hector.png");

    public HectorRenderer(EntityRendererProvider.Context context) {
        super(context, new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER)), 0.6F);
    }

    @Override
    public ResourceLocation getTextureLocation(HectorEntity entity) {
        return TEXTURE;
    }

    @Override
    protected void scale(HectorEntity entity, PoseStack poseStack, float partialTick) {
        poseStack.scale(1.2F, 1.2F, 1.2F);
    }
}
