package com.achilles.client;

import com.achilles.Achilles;
import com.achilles.network.MapActionPacket;
import com.achilles.network.NetworkHandler;
import com.achilles.network.OpenMapPacket;
import com.achilles.travel.TravelHelper;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.FormattedCharSequence;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;

import javax.annotation.Nullable;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * Mapa de Achilles: un pergamino medieval con un icono por cada estatua desbloqueada, con su nombre/apodo.
 * Rueda del ratón = zoom, arrastrar = mover el mapa, clic en un icono = elegir estatua.
 * Con el Mapa se viaja a la estatua; con el Ojo de Achilles se contempla su zona como espectador.
 */
public class AchillesMapScreen extends Screen {
    private static final ResourceLocation PARCHMENT = new ResourceLocation(Achilles.MODID, "textures/gui/map_parchment.png");
    private static final ResourceLocation MARKER = new ResourceLocation(Achilles.MODID, "textures/gui/statue_marker.png");
    private static final int INK = 0x3B2410;
    private static final int INK_RED = 0x8B1A1A;

    private int mode;
    private List<OpenMapPacket.Entry> entries = new ArrayList<>();
    private final List<String> dims = new ArrayList<>();
    private int dimIndex;
    private UUID selected;
    private double centerX;
    private double centerZ;
    private double scale = 1.0D;
    private boolean viewReady;

    private int mapX;
    private int mapY;
    private int mapW;
    private int mapH;
    private EditBox nickBox;
    private Button renameButton;
    private Button actionButton;
    private Button dimButton;

    public AchillesMapScreen(OpenMapPacket data) {
        super(Component.translatable(data.mode == TravelHelper.MODE_EYE ? "screen.achilles.eye.title" : "screen.achilles.map.title"));
        apply(data);
    }

    public void refresh(OpenMapPacket data) {
        apply(data);
        updateButtons();
    }

    private void apply(OpenMapPacket data) {
        this.mode = data.mode;
        this.entries = new ArrayList<>(data.entries);
        String keep = dims.isEmpty() ? null : dims.get(dimIndex);
        dims.clear();
        for (OpenMapPacket.Entry e : entries) {
            if (!dims.contains(e.dim())) dims.add(e.dim());
        }
        dimIndex = 0;
        int idx = dims.indexOf(keep != null ? keep : data.currentDim);
        if (idx >= 0) dimIndex = idx;
        if (selected != null && findSelected() == null) selected = null;
    }

    // ------------------------------------------------------------ datos

    private List<OpenMapPacket.Entry> current() {
        List<OpenMapPacket.Entry> list = new ArrayList<>();
        if (dims.isEmpty()) return list;
        String dim = dims.get(dimIndex);
        for (OpenMapPacket.Entry e : entries) {
            if (e.dim().equals(dim)) list.add(e);
        }
        return list;
    }

    @Nullable
    private OpenMapPacket.Entry findSelected() {
        if (selected == null) return null;
        for (OpenMapPacket.Entry e : entries) {
            if (e.id().equals(selected)) return e;
        }
        return null;
    }

    private String displayName(OpenMapPacket.Entry e) {
        if (!e.nick().isEmpty()) return e.nick();
        String owner = e.ownerName().isEmpty()
                ? Component.translatable("screen.achilles.map.nobody").getString() : e.ownerName();
        return Component.translatable("screen.achilles.map.statue_of", owner).getString();
    }

    private static String dimName(String dim) {
        return switch (dim) {
            case "minecraft:overworld" -> Component.translatable("screen.achilles.dim.overworld").getString();
            case "minecraft:the_nether" -> Component.translatable("screen.achilles.dim.the_nether").getString();
            case "minecraft:the_end" -> Component.translatable("screen.achilles.dim.the_end").getString();
            default -> dim.contains(":") ? dim.substring(dim.indexOf(':') + 1) : dim;
        };
    }

    // ------------------------------------------------------------ vista

    private void fitView() {
        List<OpenMapPacket.Entry> list = current();
        Minecraft mc = Minecraft.getInstance();
        double minX = Double.MAX_VALUE;
        double maxX = -Double.MAX_VALUE;
        double minZ = Double.MAX_VALUE;
        double maxZ = -Double.MAX_VALUE;
        for (OpenMapPacket.Entry e : list) {
            minX = Math.min(minX, e.pos().getX());
            maxX = Math.max(maxX, e.pos().getX());
            minZ = Math.min(minZ, e.pos().getZ());
            maxZ = Math.max(maxZ, e.pos().getZ());
        }
        boolean here = mc.player != null && !dims.isEmpty()
                && mc.player.level().dimension().location().toString().equals(dims.get(dimIndex));
        if (here || list.isEmpty()) {
            double px = mc.player != null ? mc.player.getX() : 0.0D;
            double pz = mc.player != null ? mc.player.getZ() : 0.0D;
            minX = Math.min(minX, px);
            maxX = Math.max(maxX, px);
            minZ = Math.min(minZ, pz);
            maxZ = Math.max(maxZ, pz);
        }
        centerX = (minX + maxX) / 2.0D;
        centerZ = (minZ + maxZ) / 2.0D;
        double spanX = Math.max(maxX - minX, 96.0D);
        double spanZ = Math.max(maxZ - minZ, 96.0D);
        scale = Mth.clamp(Math.min((mapW - 90.0D) / spanX, (mapH - 70.0D) / spanZ), 0.01D, 4.0D);
        viewReady = true;
    }

    private int toScreenX(double worldX) {
        return (int) Math.round(mapX + mapW / 2.0D + (worldX - centerX) * scale);
    }

    private int toScreenY(double worldZ) {
        return (int) Math.round(mapY + mapH / 2.0D + (worldZ - centerZ) * scale);
    }

    private boolean inMap(double x, double y) {
        return x >= mapX && x <= mapX + mapW && y >= mapY && y <= mapY + mapH;
    }

    @Nullable
    private OpenMapPacket.Entry entryAt(double mx, double my) {
        if (!inMap(mx, my)) return null;
        OpenMapPacket.Entry best = null;
        double bestDist = 10.0D * 10.0D;
        for (OpenMapPacket.Entry e : current()) {
            double dx = toScreenX(e.pos().getX() + 0.5D) - mx;
            double dy = toScreenY(e.pos().getZ() + 0.5D) - my;
            double d = dx * dx + dy * dy;
            if (d <= bestDist) {
                bestDist = d;
                best = e;
            }
        }
        return best;
    }

    // ------------------------------------------------------------ interfaz

    @Override
    protected void init() {
        mapW = Math.min(this.width - 30, 380);
        mapH = Math.max(90, Math.min(this.height - 90, 230));
        mapX = (this.width - mapW) / 2;
        mapY = 30;
        int py = mapY + mapH + 12;

        int nickW = (int) (mapW * 0.31D);
        int renameW = (int) (mapW * 0.19D);
        int actionW = (int) (mapW * 0.28D);
        int dimW = mapW - nickW - renameW - actionW - 12;

        nickBox = new EditBox(this.font, mapX, py, nickW, 20, Component.empty());
        nickBox.setMaxLength(TravelHelper.NICK_MAX);
        nickBox.setHint(Component.translatable("screen.achilles.map.nick_hint"));
        addRenderableWidget(nickBox);

        renameButton = addRenderableWidget(Button.builder(Component.translatable("screen.achilles.map.rename"),
                b -> rename()).bounds(mapX + nickW + 4, py, renameW, 20).build());

        actionButton = addRenderableWidget(Button.builder(Component.translatable(mode == TravelHelper.MODE_EYE
                        ? "screen.achilles.map.action_eye" : "screen.achilles.map.action_teleport"),
                b -> act()).bounds(mapX + nickW + renameW + 8, py, actionW, 20).build());

        dimButton = addRenderableWidget(Button.builder(Component.empty(),
                b -> cycleDimension()).bounds(mapX + nickW + renameW + actionW + 12, py, dimW, 20).build());

        if (!viewReady) fitView();
        OpenMapPacket.Entry sel = findSelected();
        if (sel != null) nickBox.setValue(sel.nick());
        updateButtons();
    }

    private void updateButtons() {
        if (actionButton == null) return;
        OpenMapPacket.Entry sel = findSelected();
        actionButton.active = sel != null && sel.allowed();
        renameButton.active = sel != null;
        dimButton.visible = dims.size() > 1;
        if (!dims.isEmpty()) {
            dimButton.setMessage(Component.literal(this.font.plainSubstrByWidth(dimName(dims.get(dimIndex)), dimButton.getWidth() - 8)));
        }
    }

    @Override
    public void tick() {
        updateButtons();
    }

    private void select(@Nullable OpenMapPacket.Entry entry) {
        selected = entry == null ? null : entry.id();
        nickBox.setValue(entry == null ? "" : entry.nick());
        updateButtons();
    }

    private void rename() {
        if (selected == null) return;
        NetworkHandler.CHANNEL.sendToServer(new MapActionPacket(TravelHelper.ACTION_RENAME, mode, selected, nickBox.getValue()));
    }

    private void act() {
        OpenMapPacket.Entry sel = findSelected();
        if (sel == null || !sel.allowed()) return;
        int action = mode == TravelHelper.MODE_EYE ? TravelHelper.ACTION_EYE : TravelHelper.ACTION_TELEPORT;
        NetworkHandler.CHANNEL.sendToServer(new MapActionPacket(action, mode, sel.id(), ""));
        onClose();
    }

    private void cycleDimension() {
        if (dims.size() < 2) return;
        dimIndex = (dimIndex + 1) % dims.size();
        select(null);
        fitView();
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (super.mouseClicked(mouseX, mouseY, button)) return true;
        if (button == 0 && inMap(mouseX, mouseY)) {
            OpenMapPacket.Entry hit = entryAt(mouseX, mouseY);
            if (hit != null) select(hit);
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double dragX, double dragY) {
        if (super.mouseDragged(mouseX, mouseY, button, dragX, dragY)) return true;
        if (button == 0 && inMap(mouseX, mouseY)) {
            centerX -= dragX / scale;
            centerZ -= dragY / scale;
            return true;
        }
        return false;
    }

    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double delta) {
        if (inMap(mouseX, mouseY)) {
            double worldX = centerX + (mouseX - (mapX + mapW / 2.0D)) / scale;
            double worldZ = centerZ + (mouseY - (mapY + mapH / 2.0D)) / scale;
            scale = Mth.clamp(scale * (delta > 0 ? 1.25D : 0.8D), 0.01D, 12.0D);
            // el punto bajo el cursor se queda donde está
            centerX = worldX - (mouseX - (mapX + mapW / 2.0D)) / scale;
            centerZ = worldZ - (mouseY - (mapY + mapH / 2.0D)) / scale;
            return true;
        }
        return super.mouseScrolled(mouseX, mouseY, delta);
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics);
        graphics.drawCenteredString(this.font, this.title, this.width / 2, 8, 0xFFD27F);

        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        graphics.blit(PARCHMENT, mapX - 14, mapY - 16, mapW + 28, mapH + 32, 0.0F, 0.0F, 384, 240, 384, 240);

        List<OpenMapPacket.Entry> list = current();
        Minecraft mc = Minecraft.getInstance();
        Player player = mc.player;
        OpenMapPacket.Entry hovered = null;

        graphics.enableScissor(mapX, mapY, mapX + mapW, mapY + mapH);
        if (list.isEmpty()) {
            List<FormattedCharSequence> lines = this.font.split(Component.translatable("screen.achilles.map.none"), mapW - 40);
            int y = mapY + mapH / 2 - lines.size() * 5;
            for (FormattedCharSequence line : lines) {
                graphics.drawString(this.font, line, mapX + (mapW - this.font.width(line)) / 2, y, INK, false);
                y += 10;
            }
        }
        for (OpenMapPacket.Entry e : list) {
            int sx = toScreenX(e.pos().getX() + 0.5D);
            int sy = toScreenY(e.pos().getZ() + 0.5D);
            boolean isSelected = e.id().equals(selected);
            boolean isHovered = entryAt(mouseX, mouseY) == e;
            if (isHovered) hovered = e;

            if (isSelected) {
                graphics.fill(sx - 11, sy - 11, sx + 11, sy + 11, 0x66C8963C);
                graphics.fill(sx - 11, sy - 11, sx + 11, sy - 10, 0xFF8B1A1A);
                graphics.fill(sx - 11, sy + 10, sx + 11, sy + 11, 0xFF8B1A1A);
                graphics.fill(sx - 11, sy - 11, sx - 10, sy + 11, 0xFF8B1A1A);
                graphics.fill(sx + 10, sy - 11, sx + 11, sy + 11, 0xFF8B1A1A);
            }
            float tint = e.allowed() ? 1.0F : 0.45F;
            RenderSystem.setShaderColor(tint, tint, tint, 1.0F);
            RenderSystem.enableBlend();
            graphics.blit(MARKER, sx - 8, sy - 8, 0.0F, 0.0F, 16, 16, 16, 16);
            RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);

            String label = displayName(e);
            int w = this.font.width(label);
            graphics.drawString(this.font, label, sx - w / 2, sy + 11, isSelected ? INK_RED : INK, false);
        }
        if (player != null && !dims.isEmpty()
                && player.level().dimension().location().toString().equals(dims.get(dimIndex))) {
            int px = toScreenX(player.getX());
            int py = toScreenY(player.getZ());
            graphics.fill(px - 3, py - 3, px + 4, py + 4, 0xFF3B2410);
            graphics.fill(px - 2, py - 2, px + 3, py + 3, 0xFFD02828);
        }
        graphics.disableScissor();
        RenderSystem.disableBlend();

        // línea de estado de la estatua elegida
        OpenMapPacket.Entry sel = findSelected();
        int infoY = mapY + mapH + 36;
        if (infoY + 9 < this.height) {
            Component info = sel == null
                    ? Component.translatable("screen.achilles.map.select_hint")
                    : Component.translatable("screen.achilles.map.info", displayName(sel),
                    sel.pos().getX(), sel.pos().getY(), sel.pos().getZ(),
                    sel.allowed() ? Component.empty() : Component.translatable("screen.achilles.map.locked"));
            graphics.drawCenteredString(this.font, this.font.plainSubstrByWidth(info.getString(), this.width - 20),
                    this.width / 2, infoY, sel != null && !sel.allowed() ? 0xFF7777 : 0xDDDDDD);
        }

        super.render(graphics, mouseX, mouseY, partialTick);

        if (hovered != null) {
            List<Component> tip = new ArrayList<>();
            tip.add(Component.literal(displayName(hovered)).withStyle(ChatFormatting.GOLD));
            tip.add(Component.translatable("screen.achilles.map.owner",
                    hovered.ownerName().isEmpty() ? Component.translatable("screen.achilles.map.nobody").getString() : hovered.ownerName())
                    .withStyle(ChatFormatting.GRAY));
            tip.add(Component.translatable("screen.achilles.map.coords", hovered.pos().getX(), hovered.pos().getY(), hovered.pos().getZ())
                    .withStyle(ChatFormatting.GRAY));
            tip.add(Component.translatable("screen.achilles.map.radius", String.format(Locale.ROOT, "%.0f", hovered.radius()))
                    .withStyle(ChatFormatting.GRAY));
            if (player != null && player.level().dimension().location().toString().equals(hovered.dim())) {
                double d = Math.sqrt(player.distanceToSqr(hovered.pos().getX() + 0.5D, hovered.pos().getY(), hovered.pos().getZ() + 0.5D));
                tip.add(Component.translatable("screen.achilles.map.distance", String.format(Locale.ROOT, "%.0f", d))
                        .withStyle(ChatFormatting.GRAY));
            }
            if (!hovered.allowed()) {
                tip.add(Component.translatable("screen.achilles.map.locked").withStyle(ChatFormatting.RED));
            }
            graphics.renderComponentTooltip(this.font, tip, mouseX, mouseY);
        }
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
