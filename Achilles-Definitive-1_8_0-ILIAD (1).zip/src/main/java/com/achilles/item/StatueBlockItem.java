package com.achilles.item;

import com.achilles.data.StatueIndexData;
import com.achilles.data.StatueStats;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

import javax.annotation.Nullable;
import java.util.List;
import java.util.UUID;

/**
 * La estatua como objeto. Si viene de recoger una estatua lleva dentro propietario, niveles y permisos,
 * y al colocarla los recupera. No se puede colocar si su zona tocaría la de otra estatua.
 */
public class StatueBlockItem extends BlockItem {
    public StatueBlockItem(Block block, Properties properties) {
        super(block, properties);
    }

    @Override
    protected boolean canPlace(BlockPlaceContext context, BlockState state) {
        if (!super.canPlace(context, state)) return false;
        Level level = context.getLevel();
        if (level.isClientSide || level.getServer() == null) return true;

        CompoundTag data = getBlockEntityData(context.getItemInHand());
        int radiusLevel = data == null ? 0 : Mth.clamp(data.getInt("RadiusLevel"), 0, StatueStats.MAX_LEVEL);
        UUID id = data != null && data.hasUUID("StatueId") ? data.getUUID("StatueId") : null;
        double limit = StatueIndexData.get(level.getServer())
                .maxRadiusFor(id, level.dimension().location().toString(), context.getClickedPos());
        if (limit < StatueStats.radius(radiusLevel)) {
            Player player = context.getPlayer();
            if (player != null) {
                player.displayClientMessage(Component.translatable("message.achilles.too_close"), true);
            }
            return false;
        }
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, level, tooltip, flag);
        CompoundTag data = getBlockEntityData(stack);
        if (data == null || !data.contains("RadiusLevel")) return;
        String owner = data.getString("OwnerName");
        if (!owner.isEmpty()) {
            tooltip.add(Component.translatable("tooltip.achilles.statue_owner", owner).withStyle(ChatFormatting.GOLD));
        }
        tooltip.add(Component.translatable("tooltip.achilles.statue_levels",
                data.getInt("RadiusLevel"), data.getInt("HealLevel"), data.getInt("GuardLevel")).withStyle(ChatFormatting.GRAY));
    }
}
