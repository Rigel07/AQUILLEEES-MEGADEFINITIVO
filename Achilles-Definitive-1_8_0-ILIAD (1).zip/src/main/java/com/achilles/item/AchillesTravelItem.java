package com.achilles.item;

import com.achilles.travel.TravelHelper;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;

/** Mapa de Achilles (modo 0: viajar) y Ojo de Achilles (modo 1: contemplar la zona). Ambos abren el mapa. */
public class AchillesTravelItem extends Item {
    private final int mode;

    public AchillesTravelItem(Properties properties, int mode) {
        super(properties);
        this.mode = mode;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && player instanceof ServerPlayer serverPlayer) {
            TravelHelper.openMap(serverPlayer, mode);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return mode == TravelHelper.MODE_EYE;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, level, tooltip, flag);
        tooltip.add(Component.translatable(mode == TravelHelper.MODE_EYE ? "tooltip.achilles.eye" : "tooltip.achilles.map")
                .withStyle(ChatFormatting.GRAY));
    }
}
