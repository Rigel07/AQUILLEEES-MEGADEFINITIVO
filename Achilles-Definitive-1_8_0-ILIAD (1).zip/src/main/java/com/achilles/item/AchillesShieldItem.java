package com.achilles.item;

import com.google.common.collect.ImmutableMultimap;
import com.google.common.collect.Multimap;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.ShieldItem;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;
import java.util.List;
import java.util.UUID;

/**
 * Escudo de Achilles (la Égida). Irrompible. Sostenerlo da resistencia al fuego y al daño y mucha resistencia al empuje.
 * Al bloquear devuelve el doble del daño, empuja al atacante, refleja proyectiles y lanza una onda de choque
 * (las habilidades viven en AchillesGear, enganchadas a los eventos de ModEvents).
 */
public class AchillesShieldItem extends ShieldItem {
    private static final UUID KNOCKBACK_UUID = UUID.fromString("6a1b3c5e-2d4f-4a6b-8c9d-0e1f2a3b4c5d");

    public AchillesShieldItem(Properties properties) {
        super(properties.fireResistant().rarity(Rarity.EPIC));
    }

    @Override
    public Multimap<Attribute, AttributeModifier> getDefaultAttributeModifiers(EquipmentSlot slot) {
        if (slot == EquipmentSlot.MAINHAND || slot == EquipmentSlot.OFFHAND) {
            ImmutableMultimap.Builder<Attribute, AttributeModifier> builder = ImmutableMultimap.builder();
            builder.put(Attributes.KNOCKBACK_RESISTANCE, new AttributeModifier(KNOCKBACK_UUID, "Aegis knockback",
                    0.6D, AttributeModifier.Operation.ADDITION));
            return builder.build();
        }
        return super.getDefaultAttributeModifiers(slot);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, level, tooltip, flag);
        for (int i = 1; i <= 3; i++) {
            tooltip.add(Component.translatable("tooltip.achilles.shield." + i).withStyle(ChatFormatting.GOLD));
        }
    }
}
