package com.achilles.item;

import com.achilles.entity.AchillesEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.OwnableEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.List;

/**
 * Espada de Achilles. Irrompible, 14 de daño. Cada golpe ignora la armadura (daño mágico extra), ralentiza al enemigo
 * y cura a quien la empuña. Clic derecho: Embestida (carga atravesando enemigos). Agachado + clic derecho: Ira de Aquiles.
 */
public class AchillesSwordItem extends SwordItem {
    public static final int DASH_COOLDOWN = 100;
    public static final int WRATH_COOLDOWN = 1200;

    public AchillesSwordItem(Properties properties) {
        super(AchillesTier.INSTANCE, 4, -2.2F, properties.fireResistant().rarity(Rarity.EPIC));
    }

    @Override
    public boolean hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        boolean result = super.hurtEnemy(stack, target, attacker);
        if (!attacker.level().isClientSide) {
            target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 60, 2));
            attacker.heal(3.0F);
            target.invulnerableTime = 0;
            target.hurt(attacker.damageSources().magic(), 5.0F);   // el daño mágico ignora la armadura
            if (attacker.level() instanceof ServerLevel level) {
                level.sendParticles(ParticleTypes.CRIT, target.getX(), target.getY(0.5D), target.getZ(), 10, 0.3D, 0.4D, 0.3D, 0.2D);
                level.sendParticles(ParticleTypes.HEART, attacker.getX(), attacker.getY(1.2D), attacker.getZ(), 1, 0.2D, 0.2D, 0.2D, 0.0D);
            }
        }
        return result;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (player.getCooldowns().isOnCooldown(this)) {
            return InteractionResultHolder.fail(stack);
        }
        boolean wrath = player.isShiftKeyDown();
        if (!level.isClientSide) {
            if (wrath) wrath(player);
            else charge(player);
        }
        player.getCooldowns().addCooldown(this, wrath ? WRATH_COOLDOWN : DASH_COOLDOWN);
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    /** Embestida: lanza al jugador hacia delante y daña a todo lo que cruza por el camino (9 bloques). */
    private void charge(Player player) {
        Level level = player.level();
        Vec3 look = player.getLookAngle();
        Vec3 dir = new Vec3(look.x, Math.max(look.y * 0.5D, 0.0D), look.z).normalize();
        Vec3 start = player.position();
        Vec3 end = start.add(dir.scale(9.0D));
        AABB box = new AABB(start, end).inflate(2.0D, 1.5D, 2.0D);

        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, box, e -> e != player && e.isAlive()
                && !(e instanceof AchillesEntity)
                && !(e instanceof OwnableEntity pet && player.getUUID().equals(pet.getOwnerUUID())))) {
            Vec3 rel = e.position().add(0.0D, e.getBbHeight() / 2.0D, 0.0D).subtract(start.add(0.0D, 1.0D, 0.0D));
            double t = Mth.clamp(rel.dot(dir), 0.0D, 9.0D);
            double dist = rel.subtract(dir.scale(t)).length();
            if (dist <= 1.8D + e.getBbWidth() / 2.0D) {
                e.hurt(player.damageSources().playerAttack(player), 18.0F);
                e.knockback(1.5D, -dir.x, -dir.z);
            }
        }
        player.setDeltaMovement(dir.scale(2.8D).add(0.0D, 0.15D, 0.0D));
        player.hurtMarked = true;
        player.fallDistance = 0.0F;
        if (level instanceof ServerLevel serverLevel) {
            for (int i = 0; i <= 9; i++) {
                serverLevel.sendParticles(ParticleTypes.SWEEP_ATTACK, start.x + dir.x * i, start.y + 1.0D, start.z + dir.z * i, 1, 0.0D, 0.0D, 0.0D, 0.0D);
                serverLevel.sendParticles(ParticleTypes.CRIT, start.x + dir.x * i, start.y + 1.0D, start.z + dir.z * i, 3, 0.3D, 0.3D, 0.3D, 0.1D);
            }
            serverLevel.playSound(null, player.blockPosition(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 1.2F, 0.7F);
        }
    }

    /** Ira de Aquiles: 10 s de fuerza, velocidad, resistencia, absorción y resistencia al fuego. */
    private void wrath(Player player) {
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 200, 2));
        player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 200, 1));
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 200, 1));
        player.addEffect(new MobEffectInstance(MobEffects.ABSORPTION, 200, 2));
        player.addEffect(new MobEffectInstance(MobEffects.FIRE_RESISTANCE, 200, 0));
        if (player.level() instanceof ServerLevel level) {
            level.sendParticles(ParticleTypes.FLAME, player.getX(), player.getY(1.0D), player.getZ(), 40, 0.5D, 0.8D, 0.5D, 0.05D);
            level.playSound(null, player.blockPosition(), SoundEvents.ENDER_DRAGON_GROWL, SoundSource.PLAYERS, 0.6F, 1.2F);
        }
        player.displayClientMessage(Component.translatable("message.achilles.wrath"), true);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        super.appendHoverText(stack, level, tooltip, flag);
        for (int i = 1; i <= 3; i++) {
            tooltip.add(Component.translatable("tooltip.achilles.sword." + i).withStyle(ChatFormatting.GOLD));
        }
    }
}
