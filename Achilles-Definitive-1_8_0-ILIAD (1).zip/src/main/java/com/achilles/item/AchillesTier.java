package com.achilles.item;

import net.minecraft.world.item.Tier;
import net.minecraft.world.item.crafting.Ingredient;

/** Material de la Espada de Achilles: no se rompe nunca (0 usos = sin durabilidad) y pega muy fuerte. */
public enum AchillesTier implements Tier {
    INSTANCE;

    @Override
    public int getUses() {
        return 0;
    }

    @Override
    public float getSpeed() {
        return 9.0F;
    }

    @Override
    public float getAttackDamageBonus() {
        return 9.0F;
    }

    @Override
    public int getLevel() {
        return 4;
    }

    @Override
    public int getEnchantmentValue() {
        return 25;
    }

    @Override
    public Ingredient getRepairIngredient() {
        return Ingredient.EMPTY;
    }
}
