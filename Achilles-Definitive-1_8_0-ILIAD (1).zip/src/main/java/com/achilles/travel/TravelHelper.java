package com.achilles.travel;

import com.achilles.data.PointsData;
import com.achilles.data.StatueIndexData;
import com.achilles.network.MapActionPacket;
import com.achilles.network.NetworkHandler;
import com.achilles.network.OpenMapPacket;
import com.achilles.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/** Lógica de servidor del Mapa de Achilles: lista de estatuas, apodos, teletransporte y Ojo de Achilles. */
public final class TravelHelper {
    public static final int MODE_MAP = 0;
    public static final int MODE_EYE = 1;

    public static final int ACTION_TELEPORT = 0;
    public static final int ACTION_EYE = 1;
    public static final int ACTION_RENAME = 2;

    /** Ticks de espera entre dos viajes (5 s). */
    public static final int TELEPORT_COOLDOWN = 100;
    public static final int NICK_MAX = 24;

    private TravelHelper() {
    }

    // ------------------------------------------------------------ mapa

    public static void openMap(ServerPlayer player, int mode) {
        if (EyeSessions.isViewing(player)) return;
        NetworkHandler.CHANNEL.send(PacketDistributor.PLAYER.with(() -> player), buildPacket(player, mode));
    }

    /** Las estatuas que este jugador tiene desbloqueadas (las encontradas y las suyas), con su apodo. */
    private static OpenMapPacket buildPacket(ServerPlayer player, int mode) {
        MinecraftServer server = player.server;
        PointsData points = PointsData.get(server);
        List<OpenMapPacket.Entry> list = new ArrayList<>();
        for (StatueIndexData.Entry e : StatueIndexData.get(server).all()) {
            boolean mine = e.owner() != null && e.owner().equals(player.getUUID());
            if (!mine && !points.isUnlocked(player.getUUID(), e.id(), e.legacyKey())) continue;
            String nick = points.getNick(player.getUUID(), e.id());
            list.add(new OpenMapPacket.Entry(e.id(), e.dim(), e.blockPos(), e.ownerName(),
                    nick == null ? "" : nick, (float) e.radius(), e.isAllowed(player.getUUID())));
        }
        return new OpenMapPacket(mode, player.level().dimension().location().toString(), list);
    }

    private static boolean isHolding(ServerPlayer player, Item item) {
        return player.getMainHandItem().is(item) || player.getOffhandItem().is(item);
    }

    private static String cleanNick(String raw) {
        String clean = raw == null ? "" : raw.replaceAll("[\\p{Cntrl}\u00a7]", "").trim();
        return clean.length() > NICK_MAX ? clean.substring(0, NICK_MAX).trim() : clean;
    }

    /** Acción pedida desde la pantalla del mapa. Todo se valida aquí: el cliente solo propone. */
    public static void handleAction(ServerPlayer player, int action, int mode, UUID statueId, String text) {
        if (EyeSessions.isViewing(player)) return;
        MinecraftServer server = player.server;
        StatueIndexData.Entry entry = StatueIndexData.get(server).get(statueId);
        PointsData points = PointsData.get(server);
        boolean holdsMap = isHolding(player, ModItems.MAP.get());
        boolean holdsEye = isHolding(player, ModItems.EYE.get());
        if (!holdsMap && !holdsEye) {
            player.displayClientMessage(Component.translatable("message.achilles.not_holding"), true);
            return;
        }
        boolean mine = entry != null && entry.owner() != null && entry.owner().equals(player.getUUID());
        if (entry == null || (!mine && !points.isUnlocked(player.getUUID(), statueId, entry.legacyKey()))) {
            player.displayClientMessage(Component.translatable("message.achilles.statue_missing"), true);
            return;
        }

        switch (action) {
            case ACTION_RENAME -> {
                points.setNick(player.getUUID(), statueId, cleanNick(text));
                player.displayClientMessage(Component.translatable("message.achilles.nick_saved"), true);
                openMap(player, holdsMap && mode == MODE_MAP ? MODE_MAP : (holdsEye ? MODE_EYE : MODE_MAP));
            }
            case ACTION_TELEPORT -> {
                if (!holdsMap) return;
                if (player.getCooldowns().isOnCooldown(ModItems.MAP.get())) return;
                if (!entry.isAllowed(player.getUUID())) {
                    player.displayClientMessage(Component.translatable("message.achilles.teleport_denied"), true);
                    return;
                }
                String nick = points.getNick(player.getUUID(), statueId);
                teleportTo(player, entry, nick == null || nick.isEmpty() ? null : nick);
            }
            case ACTION_EYE -> {
                if (!holdsEye) return;
                if (player.getCooldowns().isOnCooldown(ModItems.EYE.get())) return;
                if (!entry.isAllowed(player.getUUID())) {
                    player.displayClientMessage(Component.translatable("message.achilles.teleport_denied"), true);
                    return;
                }
                EyeSessions.start(player, entry);
            }
            default -> {
            }
        }
    }

    // ------------------------------------------------------------ teletransporte

    static ServerLevel levelOf(MinecraftServer server, String dim) {
        ResourceLocation id = ResourceLocation.tryParse(dim);
        if (id == null) return null;
        return server.getLevel(ResourceKey.create(Registries.DIMENSION, id));
    }

    private static void teleportTo(ServerPlayer player, StatueIndexData.Entry entry, String nick) {
        ServerLevel target = levelOf(player.server, entry.dim());
        if (target == null) {
            player.displayClientMessage(Component.translatable("message.achilles.statue_missing"), true);
            return;
        }
        BlockPos statuePos = entry.blockPos();
        Vec3 dest = findLanding(target, statuePos);
        double dx = statuePos.getX() + 0.5D - dest.x;
        double dz = statuePos.getZ() + 0.5D - dest.z;
        float yaw = (float) (Mth.atan2(-dx, dz) * (180.0D / Math.PI));

        ServerLevel from = player.serverLevel();
        from.sendParticles(ParticleTypes.PORTAL, player.getX(), player.getY(1.0D), player.getZ(), 40, 0.4D, 0.8D, 0.4D, 0.2D);
        from.playSound(null, player.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 0.8F, 1.2F);

        player.stopRiding();
        player.teleportTo(target, dest.x, dest.y, dest.z, yaw, 0.0F);
        player.fallDistance = 0.0F;

        target.sendParticles(ParticleTypes.TOTEM_OF_UNDYING, dest.x, dest.y + 1.0D, dest.z, 30, 0.4D, 0.8D, 0.4D, 0.2D);
        target.playSound(null, BlockPos.containing(dest), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 0.8F, 1.0F);
        player.getCooldowns().addCooldown(ModItems.MAP.get(), TELEPORT_COOLDOWN);
        Component name = nick != null ? Component.literal(nick)
                : Component.translatable("screen.achilles.map.statue_of", entry.ownerName().isEmpty()
                ? Component.translatable("screen.achilles.map.nobody").getString() : entry.ownerName());
        player.displayClientMessage(Component.translatable("message.achilles.teleported", name), true);
    }

    /** Un sitio seguro (suelo firme, dos bloques libres, sin líquidos) junto a la estatua. */
    private static Vec3 findLanding(ServerLevel level, BlockPos statue) {
        int[][] offsets = {{2, 0}, {-2, 0}, {0, 2}, {0, -2}, {2, 2}, {-2, 2}, {2, -2}, {-2, -2},
                {3, 0}, {-3, 0}, {0, 3}, {0, -3}};
        int[] dys = {0, 1, -1, 2, -2};
        for (int[] o : offsets) {
            for (int dy : dys) {
                BlockPos feet = statue.offset(o[0], dy, o[1]);
                if (isSafe(level, feet)) return Vec3.atBottomCenterOf(feet);
            }
        }
        return Vec3.atBottomCenterOf(statue.above(2));
    }

    private static boolean isSafe(ServerLevel level, BlockPos feet) {
        BlockPos head = feet.above();
        BlockPos floor = feet.below();
        return level.getBlockState(feet).getCollisionShape(level, feet).isEmpty()
                && level.getBlockState(head).getCollisionShape(level, head).isEmpty()
                && level.getFluidState(feet).isEmpty()
                && level.getFluidState(head).isEmpty()
                && level.getBlockState(floor).isFaceSturdy(level, floor, Direction.UP);
    }
}
