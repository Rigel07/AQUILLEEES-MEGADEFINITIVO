package com.achilles.travel;

import com.achilles.data.StatueIndexData;
import com.achilles.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.GameType;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Ojo de Achilles: el jugador pasa a modo espectador junto a la estatua elegida y puede volar libremente
 * por su zona de protección (sin salir de ella). Para volver: mantener Shift ~1,5 s (o esperar 5 minutos).
 * El origen (posición y modo de juego) se guarda también en los datos del jugador, así que si el servidor
 * se cae o el jugador se desconecta, al volver a entrar recupera su sitio y su modo de juego.
 */
public final class EyeSessions {
    private static final String TAG = "AchillesEye";
    private static final int MAX_TICKS = 6000;
    private static final int EXIT_SHIFT_TICKS = 30;
    private static final int COOLDOWN_TICKS = 200;

    private static final Map<UUID, Session> SESSIONS = new ConcurrentHashMap<>();

    private static final class Session {
        final UUID statueId;
        String dim;
        BlockPos pos;
        double radius;
        int age;
        int shift;

        Session(UUID statueId, String dim, BlockPos pos, double radius) {
            this.statueId = statueId;
            this.dim = dim;
            this.pos = pos;
            this.radius = radius;
        }
    }

    private EyeSessions() {
    }

    public static boolean isViewing(ServerPlayer player) {
        return SESSIONS.containsKey(player.getUUID());
    }

    public static void start(ServerPlayer player, StatueIndexData.Entry entry) {
        if (isViewing(player) || player.isSpectator() || player.getPersistentData().contains(TAG)) return;
        ServerLevel target = TravelHelper.levelOf(player.server, entry.dim());
        if (target == null) {
            player.displayClientMessage(Component.translatable("message.achilles.statue_missing"), true);
            return;
        }

        CompoundTag origin = new CompoundTag();
        origin.putString("Dim", player.level().dimension().location().toString());
        origin.putDouble("X", player.getX());
        origin.putDouble("Y", player.getY());
        origin.putDouble("Z", player.getZ());
        origin.putFloat("Yaw", player.getYRot());
        origin.putFloat("Pitch", player.getXRot());
        origin.putInt("Mode", player.gameMode.getGameModeForPlayer().getId());
        player.getPersistentData().put(TAG, origin);

        Vec3 spawn = Vec3.atCenterOf(entry.blockPos()).add(0.0D, 3.0D, 0.0D);
        player.stopRiding();
        player.setGameMode(GameType.SPECTATOR);
        player.teleportTo(target, spawn.x, spawn.y, spawn.z, player.getYRot(), 25.0F);
        SESSIONS.put(player.getUUID(), new Session(entry.id(), entry.dim(), entry.blockPos(), entry.radius()));
        player.displayClientMessage(Component.translatable("message.achilles.eye_start"), false);
    }

    /** Se llama cada tick de cada jugador del servidor. */
    public static void tick(ServerPlayer player) {
        Session s = SESSIONS.get(player.getUUID());
        if (s == null) {
            // sesión huérfana (caída del servidor, reconexión...): devolver al jugador a su sitio
            if (player.getPersistentData().contains(TAG)) restore(player);
            return;
        }
        s.age++;
        if (player.isShiftKeyDown()) s.shift++;
        else s.shift = 0;

        if (s.shift >= EXIT_SHIFT_TICKS) {
            stop(player, "message.achilles.eye_end");
            return;
        }
        if (s.age >= MAX_TICKS) {
            stop(player, "message.achilles.eye_timeout");
            return;
        }
        if (!player.isSpectator()) {
            stop(player, null);
            return;
        }

        if (s.age % 20 == 0) {
            StatueIndexData.Entry entry = StatueIndexData.get(player.server).get(s.statueId);
            if (entry == null || !entry.isAllowed(player.getUUID())) {
                stop(player, "message.achilles.eye_lost");
                return;
            }
            s.dim = entry.dim();
            s.pos = entry.blockPos();
            s.radius = entry.radius();
            int left = (MAX_TICKS - s.age) / 20;
            player.displayClientMessage(Component.translatable("message.achilles.eye_hint", left), true);
        }

        ServerLevel target = TravelHelper.levelOf(player.server, s.dim);
        if (target == null) {
            stop(player, "message.achilles.eye_lost");
            return;
        }
        Vec3 center = Vec3.atCenterOf(s.pos).add(0.0D, 0.5D, 0.0D);
        if (player.level() != target) {
            Vec3 back = center.add(0.0D, 3.0D, 0.0D);
            player.teleportTo(target, back.x, back.y, back.z, player.getYRot(), player.getXRot());
            return;
        }
        double limit = Math.max(2.0D, s.radius - 0.75D);
        Vec3 offset = player.position().subtract(center);
        if (offset.lengthSqr() > limit * limit) {
            // se pasaba del borde de la zona (también si espiaba a una entidad que salió): se le devuelve dentro
            Vec3 dir = offset.lengthSqr() < 1.0E-6D ? new Vec3(0.0D, 1.0D, 0.0D) : offset.normalize();
            Vec3 back = center.add(dir.scale(Math.max(1.0D, limit - 1.5D)));
            player.setCamera(player);
            player.teleportTo(target, back.x, back.y, back.z, player.getYRot(), player.getXRot());
        }
    }

    private static void stop(ServerPlayer player, @Nullable String messageKey) {
        SESSIONS.remove(player.getUUID());
        restore(player);
        if (messageKey != null) player.displayClientMessage(Component.translatable(messageKey), true);
        player.getCooldowns().addCooldown(ModItems.EYE.get(), COOLDOWN_TICKS);
    }

    /** Devuelve al jugador a su posición y modo de juego originales y borra la marca. */
    private static void restore(ServerPlayer player) {
        CompoundTag origin = player.getPersistentData().getCompound(TAG);
        player.getPersistentData().remove(TAG);
        player.setCamera(player);

        GameType mode = GameType.byId(origin.getInt("Mode"));
        if (mode == GameType.SPECTATOR && !origin.contains("Mode")) mode = GameType.SURVIVAL;
        if (!origin.contains("Mode")) mode = GameType.SURVIVAL;
        player.setGameMode(mode);

        if (origin.contains("X")) {
            ServerLevel level = TravelHelper.levelOf(player.server, origin.getString("Dim"));
            if (level == null) level = player.serverLevel();
            player.teleportTo(level, origin.getDouble("X"), origin.getDouble("Y"), origin.getDouble("Z"),
                    origin.getFloat("Yaw"), origin.getFloat("Pitch"));
        }
        player.fallDistance = 0.0F;
    }

    /** El jugador se desconecta: se olvida la sesión en memoria (la marca del jugador se queda para el próximo login). */
    public static void forget(ServerPlayer player) {
        SESSIONS.remove(player.getUUID());
    }

    /** El jugador reaparece tras morir: no debe arrastrar una sesión del Ojo. */
    public static void clear(ServerPlayer player) {
        SESSIONS.remove(player.getUUID());
        player.getPersistentData().remove(TAG);
    }
}
