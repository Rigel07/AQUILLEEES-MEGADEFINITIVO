package com.achilles.data;

/**
 * Números de equilibrio de las estatuas. Cada punto de radio suma 1 bloque (nivel 100 = 108 bloques).
 * Las estatuas generadas por el mundo están separadas más de 220 bloques y, además, el radio de una
 * estatua nunca puede crecer hasta tocar la zona de otra (ver StatueIndexData#maxRadiusFor).
 */
public final class StatueStats {
    public static final int MAX_LEVEL = 100;
    public static final double BASE_RADIUS = 8.0D;
    public static final double RADIUS_PER_LEVEL = 1.0D;
    public static final float BASE_HEAL_PER_SECOND = 0.5F;
    public static final float HEAL_PER_LEVEL = 0.1F;
    /** Puntos que recibe un jugador la primera vez que encuentra una estatua. */
    public static final int DISCOVERY_POINTS = 5;
    /** Mejora del mini Aquiles guardián: vida y daño extra por nivel (hasta el nivel 100). */
    public static final double GUARD_HEALTH_PER_LEVEL = 0.5D;
    public static final double GUARD_DAMAGE_PER_LEVEL = 0.1D;
    public static final double GUARD_BASE_HEALTH = 12.0D;
    public static final double GUARD_BASE_DAMAGE = 1.0D;

    /** Nivel total (radio + curación + mini Aquiles) a partir del cual el propietario puede recoger la estatua. */
    public static final int CARRY_LEVEL = 25;
    /** Niveles totales que desbloquean las ventajas de la zona (ver StatueBlockEntity#applyPerks). */
    public static final int[] PERK_LEVELS = {25, 50, 75, 100, 125, 150, 200, 250, 300};

    private StatueStats() {
    }

    public static int totalLevel(int radiusLevel, int healLevel, int guardLevel) {
        return radiusLevel + healLevel + guardLevel;
    }

    public static boolean canCarry(int totalLevel) {
        return totalLevel >= CARRY_LEVEL;
    }

    public static int perksUnlocked(int totalLevel) {
        int count = 0;
        for (int level : PERK_LEVELS) {
            if (totalLevel >= level) count++;
        }
        return count;
    }

    /** Nivel total de la siguiente ventaja, o -1 si ya están todas. */
    public static int nextPerkLevel(int totalLevel) {
        for (int level : PERK_LEVELS) {
            if (totalLevel < level) return level;
        }
        return -1;
    }

    /** Mayor nivel de radio cuyo radio cabe en "limit" bloques (Double.MAX_VALUE = sin límite). */
    public static int radiusLevelForLimit(double limit) {
        if (limit >= Double.MAX_VALUE / 2.0D) return MAX_LEVEL;
        int level = (int) Math.floor((limit - BASE_RADIUS) / RADIUS_PER_LEVEL);
        return Math.max(0, Math.min(MAX_LEVEL, level));
    }

    public static double radius(int radiusLevel) {
        return BASE_RADIUS + RADIUS_PER_LEVEL * radiusLevel;
    }

    public static double guardHealth(int guardLevel) {
        return GUARD_BASE_HEALTH + GUARD_HEALTH_PER_LEVEL * guardLevel;
    }

    public static double guardDamage(int guardLevel) {
        return GUARD_BASE_DAMAGE + GUARD_DAMAGE_PER_LEVEL * guardLevel;
    }

    public static float healPerSecond(int healLevel) {
        return BASE_HEAL_PER_SECOND + HEAL_PER_LEVEL * healLevel;
    }
}
