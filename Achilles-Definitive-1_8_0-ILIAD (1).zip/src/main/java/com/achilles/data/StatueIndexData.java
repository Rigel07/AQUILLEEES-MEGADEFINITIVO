package com.achilles.data;

import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

import javax.annotation.Nullable;
import java.util.Collection;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Índice global de estatuas colocadas en el mundo (se guarda en el overworld). Sirve para el Mapa de Achilles,
 * el Ojo de Achilles y para que dos zonas nunca se solapen, aunque la estatua esté en un chunk descargado.
 */
public class StatueIndexData extends SavedData {
    private static final String NAME = "achilles_statue_index";

    /** Datos mínimos de una estatua. "legacyKey" es la clave antigua (dimensión|posición) de la versión 1.6.0. */
    public record Entry(UUID id, String dim, long pos, @Nullable UUID owner, String ownerName,
                        String legacyKey, double radius, Set<UUID> trusted) {
        public BlockPos blockPos() {
            return BlockPos.of(pos);
        }

        public boolean isAllowed(UUID player) {
            return owner == null || owner.equals(player) || trusted.contains(player);
        }
    }

    private final Map<UUID, Entry> entries = new LinkedHashMap<>();

    public static StatueIndexData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(StatueIndexData::load, StatueIndexData::new, NAME);
    }

    public static StatueIndexData load(CompoundTag tag) {
        StatueIndexData data = new StatueIndexData();
        ListTag list = tag.getList("Statues", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag t = list.getCompound(i);
            try {
                UUID id = UUID.fromString(t.getString("Id"));
                UUID owner = t.contains("Owner") ? UUID.fromString(t.getString("Owner")) : null;
                Set<UUID> trusted = new HashSet<>();
                ListTag trustedList = t.getList("Trusted", Tag.TAG_STRING);
                for (int j = 0; j < trustedList.size(); j++) trusted.add(UUID.fromString(trustedList.getString(j)));
                data.entries.put(id, new Entry(id, t.getString("Dim"), t.getLong("Pos"), owner, t.getString("OwnerName"),
                        t.getString("Legacy"), t.getDouble("Radius"), Set.copyOf(trusted)));
            } catch (IllegalArgumentException ignored) {
                // entrada corrupta: se descarta
            }
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (Entry e : entries.values()) {
            CompoundTag t = new CompoundTag();
            t.putString("Id", e.id().toString());
            t.putString("Dim", e.dim());
            t.putLong("Pos", e.pos());
            if (e.owner() != null) t.putString("Owner", e.owner().toString());
            t.putString("OwnerName", e.ownerName());
            t.putString("Legacy", e.legacyKey());
            t.putDouble("Radius", e.radius());
            ListTag trustedList = new ListTag();
            for (UUID u : e.trusted()) trustedList.add(StringTag.valueOf(u.toString()));
            t.put("Trusted", trustedList);
            list.add(t);
        }
        tag.put("Statues", list);
        return tag;
    }

    public void put(Entry entry) {
        Entry old = entries.put(entry.id(), entry);
        if (!entry.equals(old)) setDirty();
    }

    public void remove(UUID id) {
        if (id != null && entries.remove(id) != null) setDirty();
    }

    @Nullable
    public Entry get(UUID id) {
        return entries.get(id);
    }

    public Collection<Entry> all() {
        return entries.values();
    }

    /**
     * Mayor radio que puede tener una estatua en esa posición sin tocar la zona de otra
     * (distancia al centro de otra estatua de la misma dimensión menos el radio de esa). Double.MAX_VALUE = sin límite.
     */
    public double maxRadiusFor(@Nullable UUID self, String dim, BlockPos pos) {
        double limit = Double.MAX_VALUE;
        for (Entry e : entries.values()) {
            if (e.id().equals(self) || !e.dim().equals(dim)) continue;
            double distance = Math.sqrt(pos.distSqr(e.blockPos()));
            limit = Math.min(limit, distance - e.radius());
        }
        return limit;
    }
}
