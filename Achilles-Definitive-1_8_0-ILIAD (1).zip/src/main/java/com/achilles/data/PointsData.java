package com.achilles.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.nbt.Tag;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.level.saveddata.SavedData;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/** Puntos de estatua por jugador (5 por cada estatua encontrada). Se guarda en el mundo (overworld). */
public class PointsData extends SavedData {
    private static final String NAME = "achilles_points";

    /** UUID -> { ganados, gastados } */
    private final Map<UUID, int[]> points = new HashMap<>();
    /** UUID -> estatuas ya encontradas ("dimensión|posición"). */
    private final Map<UUID, Set<String>> found = new HashMap<>();
    /** UUID jugador -> (UUID estatua -> apodo que ese jugador le puso en su mapa). */
    private final Map<UUID, Map<UUID, String>> nicks = new HashMap<>();

    public static PointsData get(MinecraftServer server) {
        return server.overworld().getDataStorage().computeIfAbsent(PointsData::load, PointsData::new, NAME);
    }

    public static PointsData load(CompoundTag tag) {
        PointsData data = new PointsData();
        ListTag list = tag.getList("Players", Tag.TAG_COMPOUND);
        for (int i = 0; i < list.size(); i++) {
            CompoundTag entry = list.getCompound(i);
            UUID id = UUID.fromString(entry.getString("Id"));
            data.points.put(id, new int[]{entry.getInt("Earned"), entry.getInt("Spent")});
            ListTag foundList = entry.getList("Found", Tag.TAG_STRING);
            Set<String> set = new HashSet<>();
            for (int j = 0; j < foundList.size(); j++) set.add(foundList.getString(j));
            data.found.put(id, set);
            ListTag nickList = entry.getList("Nicks", Tag.TAG_COMPOUND);
            Map<UUID, String> nickMap = new HashMap<>();
            for (int j = 0; j < nickList.size(); j++) {
                CompoundTag n = nickList.getCompound(j);
                try {
                    nickMap.put(UUID.fromString(n.getString("Statue")), n.getString("Name"));
                } catch (IllegalArgumentException ignored) {
                    // apodo corrupto
                }
            }
            if (!nickMap.isEmpty()) data.nicks.put(id, nickMap);
        }
        return data;
    }

    @Override
    public CompoundTag save(CompoundTag tag) {
        ListTag list = new ListTag();
        for (Map.Entry<UUID, int[]> e : points.entrySet()) {
            CompoundTag entry = new CompoundTag();
            entry.putString("Id", e.getKey().toString());
            entry.putInt("Earned", e.getValue()[0]);
            entry.putInt("Spent", e.getValue()[1]);
            ListTag foundList = new ListTag();
            for (String key : found.getOrDefault(e.getKey(), Set.of())) foundList.add(StringTag.valueOf(key));
            entry.put("Found", foundList);
            ListTag nickList = new ListTag();
            for (Map.Entry<UUID, String> n : nicks.getOrDefault(e.getKey(), Map.of()).entrySet()) {
                CompoundTag nt = new CompoundTag();
                nt.putString("Statue", n.getKey().toString());
                nt.putString("Name", n.getValue());
                nickList.add(nt);
            }
            entry.put("Nicks", nickList);
            list.add(entry);
        }
        tag.put("Players", list);
        return tag;
    }

    private int[] entry(UUID id) {
        return points.computeIfAbsent(id, k -> new int[]{0, 0});
    }

    public void addPoint(UUID id) {
        entry(id)[0]++;
        setDirty();
    }

    public void addPoints(UUID id, int amount) {
        entry(id)[0] += amount;
        setDirty();
    }

    /** Marca una estatua como encontrada y da los puntos si es la primera vez. Devuelve true si se dieron. */
    public boolean discover(UUID id, String statueKey, int reward) {
        entry(id);
        if (!found.computeIfAbsent(id, k -> new HashSet<>()).add(statueKey)) return false;
        addPoints(id, reward);
        return true;
    }

    /**
     * Versión 1.7: cada estatua tiene un UUID propio (para poder moverla). "legacyKey" es la clave antigua
     * (dimensión|posición) para que los jugadores no pierdan las estatuas que ya habían encontrado.
     */
    public boolean discover(UUID id, String key, String legacyKey, int reward) {
        entry(id);
        Set<String> set = found.computeIfAbsent(id, k -> new HashSet<>());
        boolean already = set.contains(key) || (legacyKey != null && !legacyKey.isEmpty() && set.contains(legacyKey));
        if (set.add(key)) setDirty();
        if (already) return false;
        addPoints(id, reward);
        return true;
    }

    public boolean isUnlocked(UUID player, UUID statue, String legacyKey) {
        Set<String> set = found.get(player);
        if (set == null) return false;
        return set.contains(statue.toString()) || (legacyKey != null && !legacyKey.isEmpty() && set.contains(legacyKey));
    }

    @javax.annotation.Nullable
    public String getNick(UUID player, UUID statue) {
        Map<UUID, String> map = nicks.get(player);
        return map == null ? null : map.get(statue);
    }

    public void setNick(UUID player, UUID statue, String nick) {
        entry(player);
        Map<UUID, String> map = nicks.computeIfAbsent(player, k -> new HashMap<>());
        if (nick == null || nick.isBlank()) map.remove(statue);
        else map.put(statue, nick);
        setDirty();
    }

    public int available(UUID id) {
        int[] e = entry(id);
        return Math.max(0, e[0] - e[1]);
    }

    public void spend(UUID id, int amount) {
        entry(id)[1] += amount;
        setDirty();
    }
}
