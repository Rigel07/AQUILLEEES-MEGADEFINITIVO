package com.achilles.registry;

import com.achilles.Achilles;
import com.achilles.entity.AchillesEntity;
import com.achilles.entity.HectorEntity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, Achilles.MODID);

    public static final RegistryObject<EntityType<AchillesEntity>> ACHILLES = ENTITIES.register("achilles",
            () -> EntityType.Builder.of(AchillesEntity::new, MobCategory.CREATURE)
                    .sized(0.5F, 0.9F)
                    .clientTrackingRange(8)
                    .build(Achilles.MODID + ":achilles"));

    /** Héctor, el enemigo mortal de Aquiles: jefe raro y hostil. */
    public static final RegistryObject<EntityType<HectorEntity>> HECTOR = ENTITIES.register("hector",
            () -> EntityType.Builder.of(HectorEntity::new, MobCategory.MONSTER)
                    .sized(0.7F, 2.15F)
                    .clientTrackingRange(10)
                    .build(Achilles.MODID + ":hector"));
}
