package com.achilles.registry;

import com.achilles.Achilles;
import com.achilles.item.AchillesShieldItem;
import com.achilles.item.AchillesSwordItem;
import com.achilles.item.AchillesTravelItem;
import com.achilles.item.StatueBlockItem;
import com.achilles.travel.TravelHelper;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, Achilles.MODID);

    /** Solo para creativo / administradores: las estatuas "de verdad" aparecen solas con el mundo. */
    public static final RegistryObject<Item> STATUE = ITEMS.register("achilles_statue",
            () -> new StatueBlockItem(ModBlocks.STATUE.get(), new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));

    /** Mapa medieval: muestra las estatuas desbloqueadas (con apodo) y permite viajar a ellas. */
    public static final RegistryObject<Item> MAP = ITEMS.register("achilles_map",
            () -> new AchillesTravelItem(new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON), TravelHelper.MODE_MAP));

    /** Ojo de Achilles: elige una estatua en el mapa y contempla libremente su zona (como espectador). */
    public static final RegistryObject<Item> EYE = ITEMS.register("achilles_eye",
            () -> new AchillesTravelItem(new Item.Properties().stacksTo(1).rarity(Rarity.RARE), TravelHelper.MODE_EYE));

    /** Espada de Achilles: irrompible, ignora armadura, cura, embestida e Ira de Aquiles. */
    public static final RegistryObject<Item> SWORD = ITEMS.register("achilles_sword",
            () -> new AchillesSwordItem(new Item.Properties()));

    /** Escudo de Achilles (la Égida): irrompible, devuelve el daño, refleja proyectiles, onda de choque. */
    public static final RegistryObject<Item> SHIELD = ITEMS.register("achilles_shield",
            () -> new AchillesShieldItem(new Item.Properties()));

    /** Lo suelta Héctor; con él se forjan la Espada y el Escudo de Achilles. */
    public static final RegistryObject<Item> TROJAN_BRONZE = ITEMS.register("trojan_bronze",
            () -> new Item(new Item.Properties().rarity(Rarity.RARE)));

    public static final RegistryObject<Item> HECTOR_SPAWN_EGG = ITEMS.register("hector_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.HECTOR, 0x2B4A8C, 0xD8B04A, new Item.Properties()));

    public static final RegistryObject<Item> ACHILLES_SPAWN_EGG = ITEMS.register("achilles_spawn_egg",
            () -> new ForgeSpawnEggItem(ModEntities.ACHILLES, 0xC8963C, 0xB22222, new Item.Properties()));
}
