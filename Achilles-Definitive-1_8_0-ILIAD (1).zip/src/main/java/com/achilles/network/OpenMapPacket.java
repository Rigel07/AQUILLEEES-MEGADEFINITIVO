package com.achilles.network;

import com.achilles.client.ClientHooks;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.function.Supplier;

/** Servidor -> cliente: abre (o refresca) el Mapa de Achilles con las estatuas que el jugador tiene desbloqueadas. */
public class OpenMapPacket {
    /** Una estatua del mapa. "allowed" = el jugador tiene permiso para entrar en su zona. */
    public record Entry(UUID id, String dim, BlockPos pos, String ownerName, String nick, float radius, boolean allowed) {
    }

    public final int mode;
    public final String currentDim;
    public final List<Entry> entries;

    public OpenMapPacket(int mode, String currentDim, List<Entry> entries) {
        this.mode = mode;
        this.currentDim = currentDim;
        this.entries = entries;
    }

    public static void encode(OpenMapPacket p, FriendlyByteBuf buf) {
        buf.writeVarInt(p.mode);
        buf.writeUtf(p.currentDim);
        buf.writeVarInt(p.entries.size());
        for (Entry e : p.entries) {
            buf.writeUUID(e.id());
            buf.writeUtf(e.dim());
            buf.writeBlockPos(e.pos());
            buf.writeUtf(e.ownerName());
            buf.writeUtf(e.nick());
            buf.writeFloat(e.radius());
            buf.writeBoolean(e.allowed());
        }
    }

    public static OpenMapPacket decode(FriendlyByteBuf buf) {
        int mode = buf.readVarInt();
        String currentDim = buf.readUtf();
        int count = buf.readVarInt();
        List<Entry> entries = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            entries.add(new Entry(buf.readUUID(), buf.readUtf(), buf.readBlockPos(), buf.readUtf(), buf.readUtf(),
                    buf.readFloat(), buf.readBoolean()));
        }
        return new OpenMapPacket(mode, currentDim, entries);
    }

    public static void handle(OpenMapPacket packet, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientHooks.openMap(packet)));
        ctx.get().setPacketHandled(true);
    }
}
