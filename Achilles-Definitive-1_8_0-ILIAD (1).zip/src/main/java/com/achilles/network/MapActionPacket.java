package com.achilles.network;

import com.achilles.travel.TravelHelper;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

import java.util.UUID;
import java.util.function.Supplier;

/** Cliente -> servidor: acción sobre una estatua del mapa (0 = teletransportar, 1 = Ojo de Achilles, 2 = apodo). */
public class MapActionPacket {
    private final int action;
    private final int mode;
    private final UUID statue;
    private final String text;

    public MapActionPacket(int action, int mode, UUID statue, String text) {
        this.action = action;
        this.mode = mode;
        this.statue = statue;
        this.text = text;
    }

    public static void encode(MapActionPacket p, FriendlyByteBuf buf) {
        buf.writeVarInt(p.action);
        buf.writeVarInt(p.mode);
        buf.writeUUID(p.statue);
        buf.writeUtf(p.text, 64);
    }

    public static MapActionPacket decode(FriendlyByteBuf buf) {
        return new MapActionPacket(buf.readVarInt(), buf.readVarInt(), buf.readUUID(), buf.readUtf(64));
    }

    public static void handle(MapActionPacket p, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() -> {
            ServerPlayer player = ctx.get().getSender();
            if (player == null) return;
            TravelHelper.handleAction(player, p.action, p.mode, p.statue, p.text);
        });
        ctx.get().setPacketHandled(true);
    }
}
